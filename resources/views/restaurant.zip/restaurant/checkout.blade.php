<!DOCTYPE html>
<html lang="en">
   <!-- Mirrored from askbootstrap.com/preview/swiggiweb/checkout.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 13 May 2021 10:23:17 GMT -->
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="">
      <meta name="author" content="">
       <meta name="csrf-token" content="{{ csrf_token() }}" />
      <link rel="icon" type="image/png" href="{{ url('img/fav.png')}}">
      <title>Swiggiweb - Online Food Ordering Website Template</title>
      <link rel="stylesheet" type="text/css" href="{{ url('restaurantasset/vendor/slick/slick.min.css')}}" />
      <link rel="stylesheet" type="text/css" href="{{ url('restaurantasset/vendor/slick/slick-theme.min.css')}}" />
      <link href="{{ url('restaurantasset/vendor/icons/feather.css')}}" rel="stylesheet" type="text/css">
      <link href="{{ url('restaurantasset/vendor/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet">
      <link href="{{ url('restaurantasset/css/style.css')}}" rel="stylesheet">
      <link href="{{ url('restaurantasset/vendor/sidebar/demo.css')}}" rel="stylesheet">
   </head>
   <body class="fixed-bottom-bar">
      @include("restaurant.header")
      <div class="osahan-checkout">
         <div class="d-none">
            <div class="bg-primary border-bottom p-3 d-flex align-items-center">
               <a class="toggle togglew toggle-2" href="#"><span></span></a>
               <h4 class="font-weight-bold m-0 text-white">Checkout</h4>
            </div>
         </div>
         <form method="POST" action="{{ route('addorder')}}">
         	@csrf
         <div class="container position-relative">
            <div class="py-5 row">
               <div class="col-md-8 mb-3">
                  <div>
                     <div class="osahan-cart-item mb-3 rounded shadow-sm bg-white overflow-hidden">
                        <div class="osahan-cart-item-profile bg-white p-3">
                           <div class="d-flex flex-column">
                              <h6 class="mb-3 font-weight-bold">Delivery Address</h6>
                              <div class="row">
                              	@foreach($useraddress as $address)
                                 <div class="custom-control col-lg-6 custom-radio mb-3 position-relative border-custom-radio">
                                    <input type="radio" id="customRadioInline1" name="addressselection" class="custom-control-input" checked value="{{$address->address_id}}">
                                    <label class="custom-control-label w-100" for="customRadioInline1">
                                       <div>
                                          <div class="p-3 bg-white rounded shadow-sm w-100">
                                             <div class="d-flex align-items-center mb-2">
                                                <h6 class="mb-0">Home</h6>
                                                <p class="mb-0 badge badge-success ml-auto"><i class="icofont-check-circled"></i> Default</p>
                                             </div>
                                             <p class="small text-muted m-0">1001 Veterans Blvd</p>
                                             <p class="small text-muted m-0">Redwood City, CA 94063</p>
                                          </div>
                                          <a  data-toggle="modal" data-target="#exampleModal" class="btn btn-block btn-light border-top">Edit</a>
                                       </div>
                                    </label>
                                 </div>
                                 @endforeach
                                <!--  <div class="custom-control col-lg-6 custom-radio position-relative border-custom-radio">
                                    <input type="radio" id="customRadioInline2" name="customRadioInline1" class="custom-control-input">
                                    <label class="custom-control-label w-100" for="customRadioInline2">
                                       <div>
                                          <div class="p-3 rounded bg-white shadow-sm w-100">
                                             <div class="d-flex align-items-center mb-2">
                                                <h6 class="mb-0">Work</h6>
                                                <p class="mb-0 badge badge-light ml-auto"><i class="icofont-check-circled"></i> Select</p>
                                             </div>
                                             <p class="small text-muted m-0">Model Town, Ludhiana</p>
                                             <p class="small text-muted m-0">Punjab 141002, India</p>
                                          </div>
                                          <a href="#" data-toggle="modal" data-target="#exampleModal" class="btn btn-block btn-light border-top">Edit</a>
                                       </div>
                                    </label>
                                 </div> -->
                              </div>

                             
                              <a class="btn btn-primary" href="#" data-toggle="modal" data-target="#addAddressModal"> ADD NEW ADDRESS </a>
                           </div>
                        </div>
                     </div>
                     <div class="accordion mb-3 rounded shadow-sm bg-white overflow-hidden" id="accordionExample">
                        <!-- <div class="osahan-card bg-white border-bottom overflow-hidden">
                           <div class="osahan-card-header" id="headingOne">
                              <h2 class="mb-0">
                                 <button class="d-flex p-3 align-items-center btn btn-link w-100" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                 <i class="feather-credit-card mr-3"></i> Credit/Debit Card
                                 <i class="feather-chevron-down ml-auto"></i>
                                 </button>
                              </h2>
                           </div>
                           <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
                              <div class="osahan-card-body border-top p-3">
                                 <h6 class="m-0">Add new card</h6>
                                 <p class="small">WE ACCEPT <span class="osahan-card ml-2 font-weight-bold">( Master Card / Visa Card / Rupay )</span></p>
                                 <form>
                                    <div class="form-row">
                                       <div class="col-md-12 form-group">
                                          <label class="form-label font-weight-bold small">Card number</label>
                                          <div class="input-group">
                                             <input placeholder="Card number" type="number" class="form-control">
                                             <div class="input-group-append"><button type="button" class="btn btn-outline-secondary"><i class="feather-credit-card"></i></button></div>
                                          </div>
                                       </div>
                                       <div class="col-md-8 form-group"><label class="form-label font-weight-bold small">Valid through(MM/YY)</label><input placeholder="Enter Valid through(MM/YY)" type="number" class="form-control"></div>
                                       <div class="col-md-4 form-group"><label class="form-label font-weight-bold small">CVV</label><input placeholder="Enter CVV Number" type="number" class="form-control"></div>
                                       <div class="col-md-12 form-group"><label class="form-label font-weight-bold small">Name on card</label><input placeholder="Enter Card number" type="text" class="form-control"></div>
                                       <div class="col-md-12 form-group mb-0">
                                          <div class="custom-control custom-checkbox"><input type="checkbox" id="custom-checkbox1" class="custom-control-input"><label title="" type="checkbox" for="custom-checkbox1" class="custom-control-label small pt-1">Securely save this card for a faster checkout next time.</label></div>
                                       </div>
                                    </div>
                                 </form>
                              </div>
                           </div>
                        </div> -->
                        <div class="osahan-card bg-white border-bottom overflow-hidden">
                           <div class="osahan-card-header" id="headingTwo">
                              <h2 class="mb-0">
                                 <button class="d-flex p-3 align-items-center btn btn-link w-100" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                 <i class="feather-globe mr-3"></i>Payment Method
                                 <i class="feather-chevron-down ml-auto"></i>
                                 </button>
                              </h2>
                           </div>
                           <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
                              <div class="osahan-card-body border-top p-3">
                                 <form>
                                    <div class="btn-group btn-group-toggle w-100" data-toggle="buttons">
                                       <label class="btn btn-outline-secondary active">
                                       <input type="radio" name="paymentMethod" id="option1" checked> COD
                                       </label>
                                       <label class="btn btn-outline-secondary">
                                       <input type="radio" name="paymentMethod" id="option2"> Razorpay
                                       </label>
                                      
                                    </div>
                                    <hr>
                                    
                                 </form>
                              </div>
                           </div>
                        </div>
                        <!-- <div class="osahan-card bg-white overflow-hidden">
                           <div class="osahan-card-header" id="headingThree">
                              <h2 class="mb-0">
                                 <button class="d-flex p-3 align-items-center btn btn-link w-100" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                 <i class="feather-dollar-sign mr-3"></i> Cash on Delivery
                                 <i class="feather-chevron-down ml-auto"></i>
                                 </button>
                              </h2>
                           </div>
                           <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                              <div class="card-body border-top">
                                 <h6 class="mb-3 mt-0 mb-3 font-weight-bold">Cash</h6>
                                 <p class="m-0">Please keep exact change handy to help us serve you better</p>
                              </div>
                           </div>
                        </div> -->
                     </div>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="osahan-cart-item rounded rounded shadow-sm overflow-hidden bg-white sticky_sidebar">
                  
                 
                  <div class="bg-white border-bottom py-2" id="cartdata">
                  	<?php 
                  	$totalcharge = 0;
                  	foreach($cartlists as $cartlist){ ?>
                     <div class="gold-members d-flex align-items-center justify-content-between px-3 py-2 border-bottom">
                        <div class="media align-items-center">
                           <div class="mr-2 text-danger">&middot;</div>
                           <div class="media-body">
                              <p class="m-0">{{$cartlist->product_name}}</p>
                           </div>
                        </div>
                        <div class="d-flex align-items-center">
                           <span class="count-number float-right"><button type="button" class="btn-sm left dec btn btn-outline-secondary"> <i class="feather-minus"></i> </button><input class="count-number-input" type="text" readonly="" value="{{$cartlist->qty}}"><button type="button" class="btn-sm right inc btn btn-outline-secondary"> <i class="feather-plus"></i> </button></span>
                           <p class="text-gray mb-0 float-right ml-2 text-muted small">Rs. {{ $cartlist->qty * $cartlist->price }}</p>
                        </div>
                     </div>
                    <?php 
                    $totalcharge += $cartlist->qty * $cartlist->price;
                }?>
                     
                  </div>
                 <!--  <div class="bg-white p-3 py-3 border-bottom clearfix">
                     <div class="input-group-sm mb-2 input-group">
                        <input placeholder="Enter promo code" type="text" class="form-control">
                        <div class="input-group-append"><button type="button" class="btn btn-primary"><i class="feather-percent"></i> APPLY</button></div>
                     </div>
                     <div class="mb-0 input-group">
                        <div class="input-group-prepend"><span class="input-group-text"><i class="feather-message-square"></i></span></div>
                        <textarea placeholder="Any suggestions? We will pass it on..." aria-label="With textarea" class="form-control"></textarea>
                     </div>
                  </div> -->
                  <div class="bg-white p-3 clearfix border-bottom">
                  	<input type="hidden" name="total" value="{{$totalcharge}}">
                  	<input type="hidden" name="delivery_charges" value="0">
                  	<input type="hidden" name="deliverydate" value="{{date('Y-m-d')}}">
                  	<input type="hidden" name="timedelivery" value="11.00-12.00">
                  	<input type="hidden" name="ui_type" value="{{$ui_type}}">
                  	
                     <p class="mb-1">Item Total <span class="float-right text-dark" id="subtotal">Rs. {{$totalcharge}}</span></p>
                     <p class="mb-1">Delivery Fee<span class="text-info ml-1"><i class="feather-info"></i></span><span class="float-right text-dark" id="delivery">Rs .0</span></p>
                     <p class="mb-1 text-success">Total Discount<span class="float-right text-success" id="total">Rs. 0</span></p>
                     <hr>
                     <h6 class="font-weight-bold mb-0" >TO PAY <span class="float-right" id="payTo">Rs.{{$totalcharge}}</span></h6>
                  </div>
                  <div class="p-3">
                     <button class="btn btn-success btn-block btn-lg" >PAY <i class="feather-arrow-right"></i></button>
                  </div>
                 
               </div>
               </div>
            </div>
         </div>
          </form>
      </div>
      @include("restaurant.footer")
      <nav id="main-nav">
         <ul class="second-nav">
            <li><a href="home.html"><i class="feather-home mr-2"></i> Homepage</a></li>
            <li><a href="my_order.html"><i class="feather-list mr-2"></i> My Orders</a></li>
            <li>
               <a href="#"><i class="feather-edit-2 mr-2"></i> Authentication</a>
               <ul>
                  <li><a href="login.html">Login</a></li>
                  <li><a href="signup.html">Register</a></li>
                  <li><a href="forgot_password.html">Forgot Password</a></li>
                  <li><a href="verification.html">Verification</a></li>
                  <li><a href="location.html">Location</a></li>
               </ul>
            </li>
            <li><a href="favorites.html"><i class="feather-heart mr-2"></i> Favorites</a></li>
            <li><a href="trending.html"><i class="feather-trending-up mr-2"></i> Trending</a></li>
            <li><a href="most_popular.html"><i class="feather-award mr-2"></i> Most Popular</a></li>
            <li><a href="restaurant.html"><i class="feather-paperclip mr-2"></i> Restaurant Detail</a></li>
            <li><a href="checkout.html"><i class="feather-list mr-2"></i> Checkout</a></li>
            <li><a href="successful.html"><i class="feather-check-circle mr-2"></i> Successful</a></li>
            <li><a href="map.html"><i class="feather-map-pin mr-2"></i> Live Map</a></li>
            <li>
               <a href="#"><i class="feather-user mr-2"></i> Profile</a>
               <ul>
                  <li><a href="profile.html">Profile</a></li>
                  <li><a href="favorites.html">Delivery support</a></li>
                  <li><a href="contact-us.html">Contact Us</a></li>
                  <li><a href="terms.html">Terms of use</a></li>
                  <li><a href="privacy.html">Privacy & Policy</a></li>
               </ul>
            </li>
            <li>
               <a href="#"><i class="feather-alert-triangle mr-2"></i> Error</a>
               <ul>
                  <li><a href="not-found.html">Not Found</a>
                  <li><a href="maintence.html"> Maintence</a>
                  <li><a href="coming-soon.html">Coming Soon</a>
               </ul>
            </li>
            <li>
               <a href="#"><i class="feather-link mr-2"></i> Navigation Link Example</a>
               <ul>
                  <li>
                     <a href="#">Link Example 1</a>
                     <ul>
                        <li>
                           <a href="#">Link Example 1.1</a>
                           <ul>
                              <li><a href="#">Link</a></li>
                              <li><a href="#">Link</a></li>
                              <li><a href="#">Link</a></li>
                              <li><a href="#">Link</a></li>
                              <li><a href="#">Link</a></li>
                           </ul>
                        </li>
                        <li>
                           <a href="#">Link Example 1.2</a>
                           <ul>
                              <li><a href="#">Link</a></li>
                              <li><a href="#">Link</a></li>
                              <li><a href="#">Link</a></li>
                              <li><a href="#">Link</a></li>
                           </ul>
                        </li>
                     </ul>
                  </li>
                  <li><a href="#">Link Example 2</a></li>
                  <li><a href="#">Link Example 3</a></li>
                  <li><a href="#">Link Example 4</a></li>
                  <li data-nav-custom-content>
                     <div class="custom-message">
                        You can add any custom content to your navigation items. This text is just an example.
                     </div>
                  </li>
               </ul>
            </li>
         </ul>
         <ul class="bottom-nav">
            <li class="email">
               <a class="text-danger" href="home.html">
                  <p class="h5 m-0"><i class="feather-home text-danger"></i></p>
                  Home
               </a>
            </li>
            <li class="github">
               <a href="faq.html">
                  <p class="h5 m-0"><i class="feather-message-circle"></i></p>
                  FAQ
               </a>
            </li>
            <li class="ko-fi">
               <a href="contact-us.html">
                  <p class="h5 m-0"><i class="feather-phone"></i></p>
                  Help
               </a>
            </li>
         </ul>
      </nav>
      <div class="modal fade" id="addAddressModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
         <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
               <div class="modal-header">
                  <h5 class="modal-title">Add Delivery Address</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                  </button>
               </div>
               	<form class="" method="POST" action="{{ route('adduseraddress',$ui_type)}}"  enctype="multipart/form-data">
				                      {{ csrf_field() }}
	               <div class="modal-body">
	              
	                     <div class="form-row">
	                        
					        
					         <div class="row">
					            <div class="col-xl-6">
					               <div class="form-group personal_div2">
					                  <label for="usr" class="personal_label">Name <i class="fa fa-star" style="color: red;font-size: 11px;"></i></label>
					                  <input type="text"  id="usr" name="name" class="form-control">
					               </div>
					            </div>
					            <div class="col-xl-6">
					               <div class="form-group personal_div2">
					                  <label for="usr" class="personal_label">Mobile No <i class="fa fa-star" style="color: red;font-size: 11px;"></i></label>
					                  <input type="text"  id="usr" name="mobile" class="form-control">
					               </div>
					            </div>
					            <div class="col-xl-6">
					               <div class="form-group personal_div2">
					                  <label for="usr" class="personal_label">House No <i class="fa fa-star" style="color: red;font-size: 11px;"></i></label>
					                  <input type="text"  id="usr" name="houseno" class="form-control">
					               </div>
					            </div>
					            <div class="col-xl-6">
					               <div class="form-group personal_div2">
					                  <label for="usr" class="personal_label">Street <i class="fa fa-star" style="color: red;font-size: 11px;"></i></label>
					                  <input type="text"  id="usr" name="street" class="form-control">
					               </div>
					            </div>
					            <div class="col-xl-6">
					               <div class="form-group personal_div2">
					                  <label for="usr" class="personal_label">City <i class="fa fa-star" style="color: red;font-size: 11px;"></i></label>
					                  <select class="form-control" name="city" onchange="getarea(this)">
					                      @foreach($city as $citydata)
					                      <option value="{{ $citydata->city_id}}">{{ $citydata->city_name}}</option>
					                      @endforeach
					                  </select>
					               </div>
					            </div>
					            <div class="col-xl-6">
					               <div class="form-group personal_div2">
					                  <label for="usr" class="personal_label">Area <i class="fa fa-star" style="color: red;font-size: 11px;"></i></label>
					                  <select class="form-control" name="area" id="areadata" ></select>
					               </div>
					            </div>
					            
					            
					            <div class="col-xl-6">
					               <div class="form-group personal_div2">
					                  <label for="usr" class="personal_label">State <i class="fa fa-star" style="color: red;font-size: 11px;"></i></label>
					                  <input type="text"  id="usr" name="state" class="form-control">
					               </div>
					            </div>
					            <div class="col-xl-6">
					               <div class="form-group personal_div2">
					                  <label for="usr" class="personal_label">Pin Code <i class="fa fa-star" style="color: red;font-size: 11px;"></i></label>
					                  <input type="text"  id="usr" name="pincode" class="form-control">
					               </div>
					            </div>
					          
					         </div>
					        
	                        <!-- <div class="col-md-12 form-group"><label class="form-label">Complete Address</label><input placeholder="Complete Address e.g. house number, street name, landmark" type="text" class="form-control"></div> -->
	                      <!--   <div class="col-md-12 form-group"><label class="form-label">Delivery Instructions</label><input placeholder="Delivery Instructions e.g. Opposite Gold Souk Mall" type="text" class="form-control"></div> -->
	                        <div class="mb-0 col-md-12 form-group">
	                           <label class="form-label">Nickname</label>
	                           <div class="btn-group btn-group-toggle w-100" data-toggle="buttons">
	                              <label class="btn btn-outline-secondary active">
	                              <input type="radio" name="type" id="option12" checked> Home
	                              </label>
	                              <label class="btn btn-outline-secondary">
	                              <input type="radio" name="type" id="option22"> Work
	                              </label>
	                              <label class="btn btn-outline-secondary">
	                              <input type="radio" name="type" id="option32"> Other
	                              </label>
	                           </div>
	                        </div>
	                     </div>
	                 
	               </div>
	               <div class="modal-footer p-0 border-0">
	                  <div class="col-6 m-0 p-0">
	                     <button type="button" class="btn border-top btn-lg btn-block" data-dismiss="modal">Close</button>
	                  </div>
	                  <div class="col-6 m-0 p-0">
	                     <button type="submit" class="btn btn-primary btn-lg btn-block">Save changes</button>
	                  </div>
	               </div>
           		</form>
            </div>
         </div>
      </div>
    
      <div class="osahan-menu-fotter fixed-bottom bg-white px-3 py-2 text-center d-none">
         <div class="row">
            <div class="col selected">
               <a href="home.html" class="text-danger small font-weight-bold text-decoration-none">
                  <p class="h4 m-0"><i class="feather-home text-danger"></i></p>
                  Home
               </a>
            </div>
            <div class="col">
               <a href="most_popular.html" class="text-dark small font-weight-bold text-decoration-none">
                  <p class="h4 m-0"><i class="feather-map-pin"></i></p>
                  Trending
               </a>
            </div>
            <div class="col bg-white rounded-circle mt-n4 px-3 py-2">
               <div class="bg-danger rounded-circle mt-n0 shadow">
                  <a href="checkout.html" class="text-white small font-weight-bold text-decoration-none">
                  <i class="feather-shopping-cart"></i>
                  </a>
               </div>
            </div>
            <div class="col">
               <a href="favorites.html" class="text-dark small font-weight-bold text-decoration-none">
                  <p class="h4 m-0"><i class="feather-heart"></i></p>
                  Favorites
               </a>
            </div>
            <div class="col">
               <a href="profile.html" class="text-dark small font-weight-bold text-decoration-none">
                  <p class="h4 m-0"><i class="feather-user"></i></p>
                  Profile
               </a>
            </div>
         </div>
      </div>
      <script type="27f231282dde0cd80c75b0ff-text/javascript" src="{{ url('restaurantasset/vendor/jquery/jquery.min.js')}}"></script>
      <script type="27f231282dde0cd80c75b0ff-text/javascript" src="{{ url('restaurantasset/vendor/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
      <script type="27f231282dde0cd80c75b0ff-text/javascript" src="{{ url('restaurantasset/vendor/slick/slick.min.js')}}"></script>
      <script type="27f231282dde0cd80c75b0ff-text/javascript" src="{{ url('restaurantasset/vendor/sidebar/hc-offcanvas-nav.js')}}"></script>
      <script type="27f231282dde0cd80c75b0ff-text/javascript" src="{{ url('restaurantasset/js/osahan.js')}}"></script>
      <script src="{{ url('restaurantasset/ajax.cloudflare.com/cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js')}}" data-cf-settings="27f231282dde0cd80c75b0ff-|49" defer=""></script>
      <script type="text/javascript">
		  
		    
		    function getarea(the)
		    {
		        var city = $(the).val();
		         $.ajax({
		             url: "{{ route('getarea') }}",
		             type:"POST",
		             headers: {
		                   'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
		                   },
		             data : {city:city},
		             success: function(result){
		                
		                $('#areadata').html(result.html);
		                $('#areadatafinal').html(result.html);
		              }
		      });
		    }
		</script>
   </body>
   <!-- Mirrored from askbootstrap.com/preview/swiggiweb/checkout.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 13 May 2021 10:23:18 GMT -->
</html>