<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="Askbootstrap">
      <meta name="author" content="Askbootstrap">
      <link rel="icon" type="image/png" href="{{ url('restaurantasset/img/fav.png') }}">
      <title>Restaurant</title>
      <link rel="stylesheet" type="text/css" href="{{ url('restaurantasset/vendor/slick/slick.min.css') }}" />
      <link rel="stylesheet" type="text/css" href="{{ url('restaurantasset/vendor/slick/slick-theme.min.css') }}" />
      <link href="{{ url('restaurantasset/vendor/icons/feather.css') }}" rel="stylesheet" type="text/css">
      <link href="{{ url('restaurantasset/vendor/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet">
      <link href="{{ url('restaurantasset/css/style.css') }}" rel="stylesheet">
      <link href="{{ url('restaurantasset/vendor/sidebar/demo.css') }}" rel="stylesheet">
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
   </head>

   <body class="fixed-bottom-bar">
      @include("restaurant.header")
      <div class="container">
         <div class="cat-slider">
            @foreach($category as $category)
            <div class="cat-item px-1 py-3">
               <a class="bg-white rounded d-block p-2 text-center shadow-sm" href="trending.html">
                  <img alt="#" src="{{ asset($category->cat_image) }}" class="img-fluid mb-2">
                  <p class="m-0 small">{{$category->cat_name}}</p>
               </a>
            </div>
            @endforeach
         </div>
      </div>
      <div class="bg-white">
         <div class="container">
            <div class="offer-slider">
               <div class="cat-item px-1 py-3">
                  <a class="d-block text-center shadow-sm" href="trending.html">
                  <img alt="#" src="{{ url('restaurantasset/img/pro1.jpg') }}" class="img-fluid rounded">
                  </a>
               </div>
               <div class="cat-item px-1 py-3">
                  <a class="d-block text-center shadow-sm" href="trending.html">
                  <img alt="#" src="{{ url('restaurantasset/img/pro2.jpg') }}" class="img-fluid rounded">
                  </a>
               </div>
               <div class="cat-item px-1 py-3">
                  <a class="d-block text-center shadow-sm" href="trending.html">
                  <img alt="#" src="{{ url('restaurantasset/img/pro3.jpg') }}" class="img-fluid rounded">
                  </a>
               </div>
               <div class="cat-item px-1 py-3">
                  <a class="d-block text-center shadow-sm" href="trending.html">
                  <img alt="#" src="{{ url('restaurantasset/img/pro4.jpg') }}" class="img-fluid rounded">
                  </a>
               </div>
               <div class="cat-item px-1 py-3">
                  <a class="d-block text-center shadow-sm" href="trending.html">
                  <img alt="#" src="{{ url('restaurantasset/img/pro2.jpg') }}" class="img-fluid rounded">
                  </a>
               </div>
            </div>
         </div>
      </div>
      <div class="container">
         <div class="pt-4 pb-2 title d-flex align-items-center">
            <h5 class="m-0">Trending this week</h5>
            <a class="font-weight-bold ml-auto" href="trending.html">View all <i class="feather-chevrons-right"></i></a>
         </div>
         <div class="trending-slider">
         	@foreach($vendorshopdetails as $vendorshopdetail)
            <div class="osahan-slider-item">
               <div class="list-card bg-white h-100 rounded overflow-hidden position-relative shadow-sm">
                  <div class="list-card-image">
                     <div class="star position-absolute"><span class="badge badge-success"><i class="feather-star"></i> 3.1 (300+)</span></div>
                     <div class="favourite-heart text-danger position-absolute"><a href="#"><i class="feather-heart"></i></a></div>
                     <div class="member-plan position-absolute"><span class="badge badge-dark">Promoted</span></div>
                     <a href="#">
                    <img alt="#" src="{{ url('restaurantasset/img/popular1.png') }}" class="img-fluid item-img w-100">
                     <!--  <img alt="#" src="{{ asset($vendorshopdetail->vendor_logo) }}" class="img-fluid item-img w-100"> -->
                     </a>
                  </div>
                  <div class="p-3 position-relative">
                     <div class="list-card-body">
                        <h6 class="mb-1"><a href="{{route('restaurantdata',$vendorshopdetail->vendor_id)}}" class="text-black">{{$vendorshopdetail->vendor_name}}
                           </a>
                        </h6>
                        <p class="text-gray mb-3">{{$vendorshopdetail->vendor_loc}}</p>
                        <p class="text-gray mb-3 time"><span class="bg-light text-dark rounded-sm pl-2 pb-1 pt-1 pr-2"><i class="feather-clock"></i>Opens at {{$vendorshopdetail->opening_time}} - Closed at {{$vendorshopdetail->closing_time}}</span> <span class="float-right text-black-50">{{$vendorshopdetail->vendor_phone }}</span></p>
                     </div>
                     <div class="list-card-badge">
                        <span class="badge badge-danger">OFFER</span> <small> Use Coupon OSAHAN50</small>
                     </div>
                  </div>
               </div>
            </div>
            @endforeach
            
         </div>
         <!-- <div class="py-3 title d-flex align-items-center">
            <h5 class="m-0">Most popular</h5>
            <a class="font-weight-bold ml-auto" href="most_popular.html">26 places <i class="feather-chevrons-right"></i></a>
         </div>
         <div class="most_popular">
            <div class="row">
               <div class="col-md-3 pb-3">
                  <div class="list-card bg-white h-100 rounded overflow-hidden position-relative shadow-sm">
                     <div class="list-card-image">
                        <div class="star position-absolute"><span class="badge badge-success"><i class="feather-star"></i> 3.1 (300+)</span></div>
                        <div class="favourite-heart text-danger position-absolute"><a href="#"><i class="feather-heart"></i></a></div>
                        <div class="member-plan position-absolute"><span class="badge badge-dark">Promoted</span></div>
                        <a href="restaurant.html">
                        <img alt="#" src="{{ url('restaurantasset/img/popular1.png') }}" class="img-fluid item-img w-100">
                        </a>
                     </div>
                     <div class="p-3 position-relative">
                        <div class="list-card-body">
                           <h6 class="mb-1"><a href="restaurant.html" class="text-black">The osahan Restaurant
                              </a>
                           </h6>
                           <p class="text-gray mb-1 small">• North • Hamburgers</p>
                           <p class="text-gray mb-1 rating"></p>
                           <ul class="rating-stars list-unstyled">
                              <li>
                                 <i class="feather-star star_active"></i>
                                 <i class="feather-star star_active"></i>
                                 <i class="feather-star star_active"></i>
                                 <i class="feather-star star_active"></i>
                                 <i class="feather-star"></i>
                              </li>
                           </ul>
                           <p></p>
                        </div>
                        <div class="list-card-badge">
                           <span class="badge badge-danger">OFFER</span> <small>65% OSAHAN50</small>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-md-3 pb-3">
                  <div class="list-card bg-white h-100 rounded overflow-hidden position-relative shadow-sm">
                     <div class="list-card-image">
                        <div class="star position-absolute"><span class="badge badge-success"><i class="feather-star"></i> 3.1 (300+)</span></div>
                        <div class="favourite-heart text-danger position-absolute"><a href="#"><i class="feather-heart"></i></a></div>
                        <div class="member-plan position-absolute"><span class="badge badge-dark">Promoted</span></div>
                        <a href="restaurant.html">
                        <img alt="#" src="{{ url('restaurantasset/img/popular2.png') }}" class="img-fluid item-img w-100">
                        </a>
                     </div>
                     <div class="p-3 position-relative">
                        <div class="list-card-body">
                           <h6 class="mb-1"><a href="restaurant.html" class="text-black">Thai Famous Indian Cuisine</a></h6>
                           <p class="text-gray mb-1 small">• Indian • Pure veg</p>
                           <p class="text-gray mb-1 rating"></p>
                           <ul class="rating-stars list-unstyled">
                              <li>
                                 <i class="feather-star star_active"></i>
                                 <i class="feather-star star_active"></i>
                                 <i class="feather-star star_active"></i>
                                 <i class="feather-star star_active"></i>
                                 <i class="feather-star"></i>
                              </li>
                           </ul>
                           <p></p>
                        </div>
                        <div class="list-card-badge">
                           <span class="badge badge-success">OFFER</span> <small>65% off</small>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-md-3 pb-3">
                  <div class="list-card bg-white h-100 rounded overflow-hidden position-relative shadow-sm">
                     <div class="list-card-image">
                        <div class="star position-absolute"><span class="badge badge-success"><i class="feather-star"></i> 3.1 (300+)</span></div>
                        <div class="favourite-heart text-danger position-absolute"><a href="#"><i class="feather-heart"></i></a></div>
                        <div class="member-plan position-absolute"><span class="badge badge-dark">Promoted</span></div>
                        <a href="restaurant.html">
                        <img alt="#" src="{{ url('restaurantasset/img/popular3.png') }}" class="img-fluid item-img w-100">
                        </a>
                     </div>
                     <div class="p-3 position-relative">
                        <div class="list-card-body">
                           <h6 class="mb-1"><a href="restaurant.html" class="text-black">The osahan Restaurant
                              </a>
                           </h6>
                           <p class="text-gray mb-1 small">• Hamburgers • Pure veg</p>
                           <p class="text-gray mb-1 rating"></p>
                           <ul class="rating-stars list-unstyled">
                              <li>
                                 <i class="feather-star star_active"></i>
                                 <i class="feather-star star_active"></i>
                                 <i class="feather-star star_active"></i>
                                 <i class="feather-star star_active"></i>
                                 <i class="feather-star"></i>
                              </li>
                           </ul>
                           <p></p>
                        </div>
                        <div class="list-card-badge">
                           <span class="badge badge-danger">OFFER</span> <small>65% OSAHAN50</small>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-md-3 pb-3">
                  <div class="list-card bg-white h-100 rounded overflow-hidden position-relative shadow-sm">
                     <div class="list-card-image">
                        <div class="star position-absolute"><span class="badge badge-success"><i class="feather-star"></i> 3.1 (300+)</span></div>
                        <div class="favourite-heart text-danger position-absolute"><a href="#"><i class="feather-heart"></i></a></div>
                        <div class="member-plan position-absolute"><span class="badge badge-dark">Promoted</span></div>
                        <a href="restaurant.html">
                        <img alt="#" src="{{ url('restaurantasset/img/popular4.png') }}" class="img-fluid item-img w-100">
                        </a>
                     </div>
                     <div class="p-3 position-relative">
                        <div class="list-card-body">
                           <h6 class="mb-1"><a href="restaurant.html" class="text-black">Bite Me Now Sandwiches</a></h6>
                           <p class="text-gray mb-1 small">American • Pure veg</p>
                           <p class="text-gray mb-1 rating"></p>
                           <ul class="rating-stars list-unstyled">
                              <li>
                                 <i class="feather-star star_active"></i>
                                 <i class="feather-star star_active"></i>
                                 <i class="feather-star star_active"></i>
                                 <i class="feather-star star_active"></i>
                                 <i class="feather-star"></i>
                              </li>
                           </ul>
                           <p></p>
                        </div>
                        <div class="list-card-badge">
                           <span class="badge badge-success">OFFER</span> <small>65% off</small>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-md-3 pb-3">
                  <div class="list-card bg-white h-100 rounded overflow-hidden position-relative shadow-sm">
                     <div class="list-card-image">
                        <div class="star position-absolute"><span class="badge badge-success"><i class="feather-star"></i> 3.1 (300+)</span></div>
                        <div class="favourite-heart text-danger position-absolute"><a href="#"><i class="feather-heart"></i></a></div>
                        <div class="member-plan position-absolute"><span class="badge badge-dark">Promoted</span></div>
                        <a href="restaurant.html">
                        <img alt="#" src="{{ url('restaurantasset/img/popular5.png') }}" class="img-fluid item-img w-100">
                        </a>
                     </div>
                     <div class="p-3 position-relative">
                        <div class="list-card-body">
                           <h6 class="mb-1"><a href="restaurant.html" class="text-black">The osahan Restaurant
                              </a>
                           </h6>
                           <p class="text-gray mb-1 small">• North • Hamburgers</p>
                           <p class="text-gray mb-1 rating"></p>
                           <ul class="rating-stars list-unstyled">
                              <li>
                                 <i class="feather-star star_active"></i>
                                 <i class="feather-star star_active"></i>
                                 <i class="feather-star star_active"></i>
                                 <i class="feather-star star_active"></i>
                                 <i class="feather-star"></i>
                              </li>
                           </ul>
                           <p></p>
                        </div>
                        <div class="list-card-badge">
                           <span class="badge badge-danger">OFFER</span> <small>65% OSAHAN50</small>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-md-3 pb-3">
                  <div class="list-card bg-white h-100 rounded overflow-hidden position-relative shadow-sm">
                     <div class="list-card-image">
                        <div class="star position-absolute"><span class="badge badge-success"><i class="feather-star"></i> 3.1 (300+)</span></div>
                        <div class="favourite-heart text-danger position-absolute"><a href="#"><i class="feather-heart"></i></a></div>
                        <div class="member-plan position-absolute"><span class="badge badge-dark">Promoted</span></div>
                        <a href="restaurant.html">
                        <img alt="#" src="{{ url('restaurantasset/img/popular6.png') }}" class="img-fluid item-img w-100">
                        </a>
                     </div>
                     <div class="p-3 position-relative">
                        <div class="list-card-body">
                           <h6 class="mb-1"><a href="restaurant.html" class="text-black">Thai Famous Indian Cuisine</a></h6>
                           <p class="text-gray mb-1 small">• Indian • Pure veg</p>
                           <p class="text-gray mb-1 rating"></p>
                           <ul class="rating-stars list-unstyled">
                              <li>
                                 <i class="feather-star star_active"></i>
                                 <i class="feather-star star_active"></i>
                                 <i class="feather-star star_active"></i>
                                 <i class="feather-star star_active"></i>
                                 <i class="feather-star"></i>
                              </li>
                           </ul>
                           <p></p>
                        </div>
                        <div class="list-card-badge">
                           <span class="badge badge-success">OFFER</span> <small>65% off</small>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-md-3 pb-3">
                  <div class="list-card bg-white h-100 rounded overflow-hidden position-relative shadow-sm">
                     <div class="list-card-image">
                        <div class="star position-absolute"><span class="badge badge-success"><i class="feather-star"></i> 3.1 (300+)</span></div>
                        <div class="favourite-heart text-danger position-absolute"><a href="#"><i class="feather-heart"></i></a></div>
                        <div class="member-plan position-absolute"><span class="badge badge-dark">Promoted</span></div>
                        <a href="restaurant.html">
                        <img alt="#" src="{{ url('restaurantasset/img/popular7.png') }}" class="img-fluid item-img w-100">
                        </a>
                     </div>
                     <div class="p-3 position-relative">
                        <div class="list-card-body">
                           <h6 class="mb-1"><a href="restaurant.html" class="text-black">The osahan Restaurant
                              </a>
                           </h6>
                           <p class="text-gray mb-1 small">• Hamburgers • Pure veg</p>
                           <p class="text-gray mb-1 rating"></p>
                           <ul class="rating-stars list-unstyled">
                              <li>
                                 <i class="feather-star star_active"></i>
                                 <i class="feather-star star_active"></i>
                                 <i class="feather-star star_active"></i>
                                 <i class="feather-star star_active"></i>
                                 <i class="feather-star"></i>
                              </li>
                           </ul>
                           <p></p>
                        </div>
                        <div class="list-card-badge">
                           <span class="badge badge-danger">OFFER</span> <small>65% OSAHAN50</small>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-md-3 pb-3">
                  <div class="list-card bg-white h-100 rounded overflow-hidden position-relative shadow-sm">
                     <div class="list-card-image">
                        <div class="star position-absolute"><span class="badge badge-success"><i class="feather-star"></i> 3.1 (300+)</span></div>
                        <div class="favourite-heart text-danger position-absolute"><a href="#"><i class="feather-heart"></i></a></div>
                        <div class="member-plan position-absolute"><span class="badge badge-dark">Promoted</span></div>
                        <a href="restaurant.html">
                        <img alt="#" src="{{ url('restaurantasset/img/popular8.png') }}" class="img-fluid item-img w-100">
                        </a>
                     </div>
                     <div class="p-3 position-relative">
                        <div class="list-card-body">
                           <h6 class="mb-1"><a href="restaurant.html" class="text-black">Bite Me Now Sandwiches</a></h6>
                           <p class="text-gray mb-1 small">American • Pure veg</p>
                           <p class="text-gray mb-1 rating"></p>
                           <ul class="rating-stars list-unstyled">
                              <li>
                                 <i class="feather-star star_active"></i>
                                 <i class="feather-star star_active"></i>
                                 <i class="feather-star star_active"></i>
                                 <i class="feather-star star_active"></i>
                                 <i class="feather-star"></i>
                              </li>
                           </ul>
                           <p></p>
                        </div>
                        <div class="list-card-badge">
                           <span class="badge badge-success">OFFER</span> <small>65% off</small>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div> -->
         <div class="pt-2 pb-3 title d-flex align-items-center">
            <h5 class="m-0">Most sales</h5>
            <a class="font-weight-bold ml-auto" href="#">26 places <i class="feather-chevrons-right"></i></a>
         </div>
         <div class="most_sale">
            <div class="row mb-3">
               <div class="col-md-4 mb-3">
                  <div class="d-flex align-items-center list-card bg-white h-100 rounded overflow-hidden position-relative shadow-sm">
                     <div class="list-card-image">
                        <div class="star position-absolute"><span class="badge badge-success"><i class="feather-star"></i> 3.1 (300+)</span></div>
                        <div class="favourite-heart text-danger position-absolute"><a href="#"><i class="feather-heart"></i></a></div>
                        <div class="member-plan position-absolute"><span class="badge badge-dark">Promoted</span></div>
                        <a href="restaurant.html">
                        <img alt="#" src="{{ url('restaurantasset/img/sales1.png') }}" class="img-fluid item-img w-100">
                        </a>
                     </div>
                     <div class="p-3 position-relative">
                        <div class="list-card-body">
                           <h6 class="mb-1"><a href="restaurant.html" class="text-black">The osahan Restaurant
                              </a>
                           </h6>
                           <p class="text-gray mb-3">North • Hamburgers • Pure veg</p>
                           <p class="text-gray mb-3 time"><span class="bg-light text-dark rounded-sm pl-2 pb-1 pt-1 pr-2"><i class="feather-clock"></i> 15–25 min</span> <span class="float-right text-black-50"> $500 FOR TWO</span></p>
                        </div>
                        <div class="list-card-badge">
                           <span class="badge badge-danger">OFFER</span> <small>65% OSAHAN50</small>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-md-4 mb-3">
                  <div class="d-flex align-items-center list-card bg-white h-100 rounded overflow-hidden position-relative shadow-sm">
                     <div class="list-card-image">
                        <div class="star position-absolute"><span class="badge badge-success"><i class="feather-star"></i> 3.1 (300+)</span></div>
                        <div class="favourite-heart text-danger position-absolute"><a href="#"><i class="feather-heart"></i></a></div>
                        <div class="member-plan position-absolute"><span class="badge badge-dark">Promoted</span></div>
                        <a href="restaurant.html">
                        <img alt="#" src="{{ url('restaurantasset/img/sales2.png') }}" class="img-fluid item-img w-100">
                        </a>
                     </div>
                     <div class="p-3 position-relative">
                        <div class="list-card-body">
                           <h6 class="mb-1"><a href="restaurant.html" class="text-black">Thai Famous Cuisine</a></h6>
                           <p class="text-gray mb-3">North Indian • Indian • Pure veg</p>
                           <p class="text-gray mb-3 time"><span class="bg-light text-dark rounded-sm pl-2 pb-1 pt-1 pr-2"><i class="feather-clock"></i> 30–35 min</span> <span class="float-right text-black-50"> $250 FOR TWO</span></p>
                        </div>
                        <div class="list-card-badge">
                           <span class="badge badge-success">OFFER</span> <small>65% off</small>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-md-4 mb-3">
                  <div class="d-flex align-items-center list-card bg-white h-100 rounded overflow-hidden position-relative shadow-sm">
                     <div class="list-card-image">
                        <div class="star position-absolute"><span class="badge badge-success"><i class="feather-star"></i> 3.1 (300+)</span></div>
                        <div class="favourite-heart text-danger position-absolute"><a href="#"><i class="feather-heart"></i></a></div>
                        <div class="member-plan position-absolute"><span class="badge badge-dark">Promoted</span></div>
                        <a href="restaurant.html">
                        <img alt="#" src="{{ url('restaurantasset/img/sales3.png') }}" class="img-fluid item-img w-100">
                        </a>
                     </div>
                     <div class="p-3 position-relative">
                        <div class="list-card-body">
                           <h6 class="mb-1"><a href="restaurant.html" class="text-black">The osahan Restaurant
                              </a>
                           </h6>
                           <p class="text-gray mb-3">North • Hamburgers • Pure veg</p>
                           <p class="text-gray mb-3 time"><span class="bg-light text-dark rounded-sm pl-2 pb-1 pt-1 pr-2"><i class="feather-clock"></i> 15–25 min</span> <span class="float-right text-black-50"> $500 FOR TWO</span></p>
                        </div>
                        <div class="list-card-badge">
                           <span class="badge badge-danger">OFFER</span> <small>65% OSAHAN50</small>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      </div>
      <div class="osahan-menu-fotter fixed-bottom bg-white px-3 py-2 text-center d-none">
         <div class="row">
            <div class="col selected">
               <a href="home.html" class="text-danger small font-weight-bold text-decoration-none">
                  <p class="h4 m-0"><i class="feather-home text-danger"></i></p>
                  Home
               </a>
            </div>
            <div class="col">
               <a href="most_popular.html" class="text-dark small font-weight-bold text-decoration-none">
                  <p class="h4 m-0"><i class="feather-map-pin"></i></p>
                  Trending
               </a>
            </div>
            <div class="col bg-white rounded-circle mt-n4 px-3 py-2">
               <div class="bg-danger rounded-circle mt-n0 shadow">
                  <a href="checkout.html" class="text-white small font-weight-bold text-decoration-none">
                  <i class="feather-shopping-cart"></i>
                  </a>
               </div>
            </div>
            <div class="col">
               <a href="favorites.html" class="text-dark small font-weight-bold text-decoration-none">
                  <p class="h4 m-0"><i class="feather-heart"></i></p>
                  Favorites
               </a>
            </div>
            <div class="col">
               <a href="profile.html" class="text-dark small font-weight-bold text-decoration-none">
                  <p class="h4 m-0"><i class="feather-user"></i></p>
                  Profile
               </a>
            </div>
         </div>
      </div>
      @include("restaurant.footer")
      <script type="e7ab6f42a3180517660229f7-text/javascript" src="{{ url('restaurantasset/vendor/jquery/jquery.min.js') }}"></script>
      <script type="e7ab6f42a3180517660229f7-text/javascript" src="{{ url('restaurantasset/vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
      <script type="e7ab6f42a3180517660229f7-text/javascript" src="{{ url('restaurantasset/vendor/slick/slick.min.js') }}"></script>
      <script type="e7ab6f42a3180517660229f7-text/javascript" src="{{ url('restaurantasset/vendor/sidebar/hc-offcanvas-nav.js') }}"></script>
      <script type="e7ab6f42a3180517660229f7-text/javascript" src="{{ url('restaurantasset/js/osahan.js') }}"></script>
      <script src="{{ url('restaurantasset/ajax.cloudflare.com/cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js') }}" data-cf-settings="e7ab6f42a3180517660229f7-|49" defer=""></script>
   </body>
   <!-- Mirrored from askbootstrap.com/preview/swiggiweb/home.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 13 May 2021 10:23:08 GMT -->
</html>