<!DOCTYPE html>

<html lang="en">
<!-- head -->



<head>
	<meta charset="utf-8" />
	<title>Excelsure | Courier &amp; Delivery Service HTML Template</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Excelsure - Courier Service HTML Template" />
	<meta name="keywords" content="Excelsure">
	<meta name="author" content="Capricorn_Theme" />
	<meta name="MobileOptimized" content="320" />

	<!-- google fonts -->
	<link href="../../../fonts.googleapis.com/css6079.css?family=Poppins:300,400,500,600,700" rel="stylesheet">
	<link href="../../../fonts.googleapis.com/css1fd7.css?family=Roboto:400,500,700" rel="stylesheet">

	<!-- Favicon -->
	<link rel="icon" type="image/icon" href="{{ url('parcelassets/images/icons/favicon.png')}}">
	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="{{ url('parcelassets/css/bootstrap.min.css')}}" type="text/css" />
	<!-- Navigation CSS -->
	<link rel="stylesheet" type="text/css" href="{{ url('parcelassets/css/menumaker.css')}}" />
	<!-- Animated CSS -->
	<link rel="stylesheet" type="text/css" href="{{ url('parcelassets/css/animate.css')}}" />
	<!-- Owl Carousel css -->
	<link rel="stylesheet" type="text/css" href="{{ url('parcelassets/css/owl.carousel.min.css')}}" />
	<!-- Line Awesome CSS -->
	<link rel="stylesheet" type="text/css" href="{{ url('parcelassets/css/line-awesome.min.css')}}" />
	<!-- Flaticon CSS -->
	<link rel="stylesheet" type="text/css" href="{{ url('parcelassets/css/flaticon.css')}}" />
	<!-- Slicknav CSS -->
	<link rel="stylesheet" type="text/css" href="{{ url('parcelassets/css/slicknav.min.css')}}" />
	<!-- Main Style CSS -->
	<link href="{{ url('parcelassets/css/style.css')}}" rel="stylesheet" type="text/css" />
	<!-- end theme styles -->
	<!-- Responsive CSS -->
	<link href="{{ url('parcelassets/css/responsive.css')}}" rel="stylesheet">

</head>
<style type="text/css">
	/*.owl-item
	{
		width:400px !important;
	}*/
</style>
<!-- end head -->
<!-- body start-->

<body>
	@include('parcel.header')
	<!-- home slider start-->
	<div id="home-slider" class="home-main-block owl-carousel">
		@foreach($parcel_banner as $banner)

		<div class="item home-slider-bg theme-3" style="background-image: url({{ url($banner->banner_image) }})">
			<div class="overlay-bg"></div>
			<div class="container">
				<div class="row">
					<div class="col-lg-7">
						<div class="slider-dtl-2">
							<div class="slider-sub-heading text-white">Service Since 1980</div>
							<h1 class="slider-heading text-white">We provide Best Dispatch &amp; Parcel Services</h1>
							<p>We provide removals to and from the Manchester space.
								we tend to might have all of the fashionable removals instrumentality
								at our disposal, however there’s additional to our service than the removal vans</p>
							<div class="slider-btn">
								<button type="button" class="btn btn-dark">Contact Us <i class="las la-arrow-right"></i></button>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		@endforeach
		
	</div>
	<!-- home slider end-->

	<!-- services start -->
	
	<div id="testimonial" class="testimonial-main-block">
		<div class="container">
			<div class="section text-center">
				<h1 class="section-heading">Parcel Service Providers</h1>
			</div>
			<div class="row">
				<div class="col-lg-12">
					<div class="team-carousel owl-carousel">
						<!-- <div class="single-team-item"> -->
						@foreach($parcel_vendor as $vendor)
							<div class="services-block-2">
								<div class="services-img">
									<a href="#" title="Real Time Status"><img src="{{ url($vendor->vendor_logo)}}" class="img-fluid-img" alt="Real Time Status"></a>
								</div>
								<div class="services-dtl-2">
									<!-- <div class="services-meta">
										<a href="#" title="Innovation">01</a>
									</div> -->
									<h4 class="services-heading"><a href="{{ route('parcel.senderdetails',$vendor->vendor_id)}}" title="standard courier">{{$vendor->vendor_name}}</a></h4>
									<p>It is a long established fact that and reader will by the readable based of content page banned.</p>
									
										<ul>
											<li><b>Email</b>: {{$vendor->vendor_email}}</li>
											<li><b>Phone</b>: {{$vendor->vendor_phone}}</li>
											<li><b>Open Time</b>: {{$vendor->opening_time}}</li>
											<li><b>Close Time: {{$vendor->closing_time}}</b></li>
											<li><b>Tracking</b>: No</li>
										</ul>
								
								</div>
							</div>
						@endforeach
						
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- <div id="clients" class="clients-main-block">
		<div class="container">
			<div class="row">
				<div id="clients-slider" class="clients-slider owl-carousel">
					<div class="item-clients-img">
						<div class="services-block-2">
							<div class="services-img">
								<a href="#" title="Real Time Status"><img src="images/service/01.jpg" class="img-fluid-img" alt="Real Time Status"></a>
							</div>
							<div class="services-dtl-2">
								<div class="services-meta">
									<a href="#" title="Innovation">01</a>
								</div>
								<h4 class="services-heading"><a href="#" title="standard courier">Standard Courier</a></h4>
								<p>It is a long established fact that and reader will by the readable based of content page banned.</p>
								<a href="#" class="btn btn-link">Read More<i class="las la-arrow-right"></i></a>
							</div>
						</div>
					</div>
					<div class="item-clients-img">
						<div class="services-block-2">
							<div class="services-img">
								<a href="#" title="Real Time Status"><img src="images/service/01.jpg" class="img-fluid-img" alt="Real Time Status"></a>
							</div>
							<div class="services-dtl-2">
								<div class="services-meta">
									<a href="#" title="Innovation">01</a>
								</div>
								<h4 class="services-heading"><a href="#" title="standard courier">Standard Courier</a></h4>
								<p>It is a long established fact that and reader will by the readable based of content page banned.</p>
								<a href="#" class="btn btn-link">Read More<i class="las la-arrow-right"></i></a>
							</div>
						</div>
					</div>
					<div class="item-clients-img">
						<div class="services-block-2">
							<div class="services-img">
								<a href="#" title="Real Time Status"><img src="images/service/01.jpg" class="img-fluid-img" alt="Real Time Status"></a>
							</div>
							<div class="services-dtl-2">
								<div class="services-meta">
									<a href="#" title="Innovation">01</a>
								</div>
								<h4 class="services-heading"><a href="#" title="standard courier">Standard Courier</a></h4>
								<p>It is a long established fact that and reader will by the readable based of content page banned.</p>
								<a href="#" class="btn btn-link">Read More<i class="las la-arrow-right"></i></a>
							</div>
						</div>
					</div>
					<div class="item-clients-img">
						<div class="services-block-2">
							<div class="services-img">
								<a href="#" title="Real Time Status"><img src="images/service/01.jpg" class="img-fluid-img" alt="Real Time Status"></a>
							</div>
							<div class="services-dtl-2">
								<div class="services-meta">
									<a href="#" title="Innovation">01</a>
								</div>
								<h4 class="services-heading"><a href="#" title="standard courier">Standard Courier</a></h4>
								<p>It is a long established fact that and reader will by the readable based of content page banned.</p>
								<a href="#" class="btn btn-link">Read More<i class="las la-arrow-right"></i></a>
							</div>
						</div>
					</div>
					<div class="item-clients-img">
						<div class="services-block-2">
							<div class="services-img">
								<a href="#" title="Real Time Status"><img src="images/service/01.jpg" class="img-fluid-img" alt="Real Time Status"></a>
							</div>
							<div class="services-dtl-2">
								<div class="services-meta">
									<a href="#" title="Innovation">01</a>
								</div>
								<h4 class="services-heading"><a href="#" title="standard courier">Standard Courier</a></h4>
								<p>It is a long established fact that and reader will by the readable based of content page banned.</p>
								<a href="#" class="btn btn-link">Read More<i class="las la-arrow-right"></i></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div> -->

	
	<!-- features end-->

	
	<!-- quotation end-->
	<!-- footer start-->
	@include('parcel.footer')
	<!-- footer end-->

	<!-- Scroll Top Area -->
	<a href="#top" class="go-top" style="display: block;"><i class="las la-angle-up"></i></a>

	<!-- Jquery Library -->
	<script src="{{ url('parcelassets/js/jquery-2.min.js')}}"></script>
	<!-- Bootstrap Js -->
	<script src="{{ url('parcelassets/js/bootstrap.bundle.js')}}"></script>
	<!-- Owl Carousel js -->
	<script src="{{ url('parcelassets/js/owl.carousel.min.js')}}"></script>
	<!-- Smooth Scroll Js -->
	<script src="{{ url('parcelassets/js/smooth-scroll.js')}}"></script>
	<!-- Navigation JS -->
	<script src="{{ url('parcelassets/js/menumaker.js')}}"></script>
	<!-- Way Points JS -->
	<script src="{{ url('parcelassets/js/waypoints.min.js')}}"></script>
	<!-- Counter Up JS -->
	<script src="{{ url('parcelassets/js/jquery.counterup.js')}}"></script>
	<!-- Sticky JS -->
	<script src="{{ url('parcelassets/js/jquery.sticky.js')}}"></script>
	<!-- Slicknav JS -->
	<script src="{{ url('parcelassets/js/jquery.slicknav.min.js')}}"></script>
	<!-- Mail Chimp JS -->
	<script src="{{ url('parcelassets/vendor/mailchimp/jquery.ajaxchimp.js')}}"></script>
	<!-- Main JS -->
	<script src="{{ url('parcelassets/js/theme.js')}}"></script>
	<!-- end JS -->

</body>
<!-- body end -->



</html>
