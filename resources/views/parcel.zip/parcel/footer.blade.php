@php
	$vendorCategory = DB::table('vendor_category')->where('ui_type',4)->first();

	@endphp
<footer id="footer" class="footer-main-block">
		<div class="container">
			<div class="row text-white">
				<div class="col-lg-3 col-sm-6">
					<div class="about-widget footer-widget">
						<div class="logo-footer">
							<a href="{{ route('parcel.parcelhome',4)}}" title="logo"><img src="{{ url($vendorCategory->category_image)}}" alt="logo" style="width:150px;height:70px"></a>
						</div>
						<p>There anyone who loves or pursues not some great to have pleasure.</p>
						<!-- <div class="row">
							<div class="col-lg-2">
								<div class="footer-icon">
									<i class="las la-home"></i>
								</div>
							</div>
							<div class="col-lg-10">
								<div class="footer-address">Corporate Office</div>
								<div class="footer-address-dtl">3029A, Melbourne, Australia</div>
							</div>
						</div>
						<div class="row">
							<div class="col-lg-2">
								<div class="footer-icon">
									<i class="las la-phone"></i>
								</div>
							</div>
							<div class="col-lg-10">
								<div class="footer-address">Reach Us</div>
								<div class="footer-address-dtl">+4 123 123 4555 8888</div>
							</div>
						</div> -->
					</div>
				</div>
				<div class="col-lg-3 col-sm-6">
					<div class="courier-type-widget footer-widget mrg-btm-30">
						<h6 class="footer text-white">For Users</h6>
						<div class="footer-list">
							<ul>
								<li><a href="services-details.html" title="link"><i class="las la-arrow-circle-right"></i> About Us</a></li>
								<li><a href="services-details.html" title="link"><i class="las la-arrow-circle-right"></i> FAQ</a></li>
								<li><a href="services-details.html" title="link"><i class="las la-arrow-circle-right"></i>Contact Us</a></li>
								<!-- <li><a href="services-details.html" title="link"><i class="las la-arrow-circle-right"></i>Ware Housing</a></li>
								<li><a href="services-details.html" title="link"><i class="las la-arrow-circle-right"></i>Overnight</a></li>
								<li><a href="services-details.html" title="link"><i class="las la-arrow-circle-right"></i>Pallet</a></li> -->
							</ul>
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-sm-6">
					<div class="courier-type-widget footer-widget mrg-btm-30">
						<h6 class="footer text-white">Services</h6>
						<div class="footer-list">
							<ul>
								<li><a href="services-details.html" title="link"><i class="las la-arrow-circle-right"></i> Terms of use</a></li>
								<li><a href="services-details.html" title="link"><i class="las la-arrow-circle-right"></i> Privacy policy</a></li>
								
								<!-- <li><a href="services-details.html" title="link"><i class="las la-arrow-circle-right"></i>Ware Housing</a></li>
								<li><a href="services-details.html" title="link"><i class="las la-arrow-circle-right"></i>Overnight</a></li>
								<li><a href="services-details.html" title="link"><i class="las la-arrow-circle-right"></i>Pallet</a></li> -->
							</ul>
						</div>
					</div>
				</div>
				
				<div class="col-lg-3 col-sm-6">
					<div class="news-widget footer-widget mrg-btm-30">
						<h6 class="footer text-white">Follow Us </h6>
						
						<div class="footer-social">
							<ul>
								
								<li><a href="https://facebook.com/" target="_blank" title="facebook"><i class="lab la-facebook-f"></i></a></li>
								<li><a href="https://twitter.com/" target="_blank" title="twitter"><i class="lab la-twitter"></i></a></li>
								<li><a href="https://plus.google.com/" target="_blank" title="linked-in"><i class="lab la-linkedin-in"></i></a></li>
								<li><a href="https://youtube.com/" target="_blank" title="youtube"><i class="lab la-youtube"></i></a></li>

							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="tiny-footer">
			<div class="container">
				<div class="row">
					<div class="col-md-6">
						<div class="copyright-block">
							<p>&copy; 2020 <a href="index-2.html" title="exelsure courier service">Excelsure</a>. All Rights Reserved.</p>
						</div>
					</div>
					
				</div>
			</div>
		</div>
	</footer>