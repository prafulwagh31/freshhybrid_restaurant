<!DOCTYPE html>

<html lang="en">
<!-- head -->



<head>
	<meta charset="utf-8" />
	<title>Excelsure | Courier &amp; Delivery Service HTML Template</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Excelsure - Courier Service HTML Template" />
	<meta name="keywords" content="Excelsure">
	<meta name="author" content="Capricorn_Theme" />
	<meta name="MobileOptimized" content="320" />

	<!-- google fonts -->
	<link href="../../../fonts.googleapis.com/css6079.css?family=Poppins:300,400,500,600,700" rel="stylesheet">
	<link href="../../../fonts.googleapis.com/css1fd7.css?family=Roboto:400,500,700" rel="stylesheet">

	<!-- Favicon -->
	<link rel="icon" type="image/icon" href="{{ url('parcelassets/images/icons/favicon.png')}}">
	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="{{ url('parcelassets/css/bootstrap.min.css')}}" type="text/css" />
	<!-- Navigation CSS -->
	<link rel="stylesheet" type="text/css" href="{{ url('parcelassets/css/menumaker.css')}}" />
	<!-- Animated CSS -->
	<link rel="stylesheet" type="text/css" href="{{ url('parcelassets/css/animate.css')}}" />
	<!-- Owl Carousel css -->
	<link rel="stylesheet" type="text/css" href="{{ url('parcelassets/css/owl.carousel.min.css')}}" />
	<!-- Line Awesome CSS -->
	<link rel="stylesheet" type="text/css" href="{{ url('parcelassets/css/line-awesome.min.css')}}" />
	<!-- Flaticon CSS -->
	<link rel="stylesheet" type="text/css" href="{{ url('parcelassets/css/flaticon.css')}}" />
	<!-- Slicknav CSS -->
	<link rel="stylesheet" type="text/css" href="{{ url('parcelassets/css/slicknav.min.css')}}" />
	<!-- Main Style CSS -->
	<link href="{{ url('parcelassets/css/style.css')}}" rel="stylesheet" type="text/css" />
	<!-- end theme styles -->
	<!-- Responsive CSS -->
	<link href="{{ url('parcelassets/css/responsive.css')}}" rel="stylesheet">

</head>
<style type="text/css">
	#nav-bar
	{
		background-color: #147b88 !important;
	}
	.quotation-block {
    position: relative !important;
    box-shadow: 0px 0px 30px 0px rgb(18 27 81 / 10%);
	}
	@media (max-width: 575px){
	#quotation {
	    
	    height: 1200px !important;
	  
	}

	}
	@media (max-width: 768px){
	#quotation {
	    
	    height: 1250px !important;
	  
	}
	}
</style>
<!-- end head -->
<!-- body start-->

<body>
	@include('parcel.header')
	<!-- home slider start-->
	
	<!-- home slider end-->

	<!-- services start -->
	<br><br>
	
	<div id="quotation" class="quotation-main-block" style="background-image: url('images/bg/consult-bg.jpg');height:1050px;">
		<div class="overlay-bg"></div>
		<div class="container">

			<div class="section text-center">
				<h1 class="section-heading">Parcel Details</h1>
			</div>

			<div class="quotation-block" >
				<div class="d-none">
				   <div class="bg-primary border-bottom p-3 d-flex align-items-center">
				      <a class="toggle togglew toggle-2" href="#"><span></span></a>
				      <h4 class="font-weight-bold m-0 text-white">My Order</h4>
				   </div>
				</div>
				<section class="py-4 osahan-main-body">
				   <div class="container">
				      <div class="row">
				         <div class="col-md-3 mb-3">
				            <ul class="nav nav-tabsa custom-tabsa border-0 flex-column bg-white rounded overflow-hidden shadow-sm p-2 c-t-order" id="myTab" role="tablist">
				               <li class="nav-item" role="presentation">
				                  <a class="nav-link border-0 text-dark py-3 active" id="completed-tab" data-toggle="tab" href="#completed" role="tab" aria-controls="completed" aria-selected="true">
				                  <i class="feather-check mr-2 text-success mb-0"></i> Completed</a>
				               </li>
				               <li class="nav-item border-top" role="presentation">
				                  <a class="nav-link border-0 text-dark py-3" id="progress-tab" data-toggle="tab" href="#progress" role="tab" aria-controls="progress" aria-selected="false">
				                  <i class="feather-clock mr-2 text-warning mb-0"></i> On Progress</a>
				               </li>
				               <li class="nav-item border-top" role="presentation">
				                  <a class="nav-link border-0 text-dark py-3" id="canceled-tab" data-toggle="tab" href="#canceled" role="tab" aria-controls="canceled" aria-selected="false">
				                  <i class="feather-x-circle mr-2 text-danger mb-0"></i> Canceled</a>
				               </li>
				            </ul>
				         </div>
				         <div class="tab-content col-md-9" id="myTabContent" style="height: 500px;overflow: auto;">
				            <div class="tab-pane fade show active" id="completed" role="tabpanel" aria-labelledby="completed-tab">
				               <div class="order-body">
				                  <div class="pb-3">
				                     <div class="p-3 rounded shadow-sm bg-white">
				                        <div class="d-flex border-bottom pb-3">
				                           <div class="text-muted mr-3">
				                              <img alt="#" src="img/popular5.png" class="img-fluid order_img rounded">
				                           </div>
				                           <div>
				                              <p class="mb-0 font-weight-bold"><a href="restaurant.html" class="text-dark">Conrad Chicago Restaurant</a></p>
				                              <p class="mb-0">Punjab, India</p>
				                              <p>ORDER #321DERS</p>
				                              <p class="mb-0 small"><a href="status_complete.html">View Details</a></p>
				                           </div>
				                           <div class="ml-auto">
				                              <p class="bg-success text-white py-1 px-2 rounded small mb-1">Delivered</p>
				                              <p class="small font-weight-bold text-center"><i class="feather-clock"></i> 06/04/2020</p>
				                           </div>
				                        </div>
				                        <div class="d-flex pt-3">
				                           <div class="small">
				                              <p class="text- font-weight-bold mb-0">Kesar Sweet x 1</p>
				                              <p class="text- font-weight-bold mb-0">Gulab Jamun x 4</p>
				                           </div>
				                           <div class="text-muted m-0 ml-auto mr-3 small">Total Payment<br>
				                              <span class="text-dark font-weight-bold">$12.74</span>
				                           </div>
				                           <div class="text-right">
				                              <a href="checkout.html" class="btn btn-primary px-3">Reorder</a>
				                              <a href="contact-us.html" class="btn btn-outline-primary px-3">Help</a>
				                           </div>
				                        </div>
				                     </div>
				                  </div>
				                  <div class="pb-3">
				                     <div class="p-3 rounded shadow-sm bg-white">
				                        <div class="d-flex border-bottom pb-3">
				                           <div class="text-muted mr-3">
				                              <img alt="#" src="img/popular4.png" class="img-fluid order_img rounded">
				                           </div>
				                           <div>
				                              <p class="mb-0 font-weight-bold"><a href="restaurant.html" class="text-dark">Conrad Chicago Restaurant</a></p>
				                              <p class="mb-0">Punjab, India</p>
				                              <p>ORDER #321DERS</p>
				                              <p class="mb-0 small"><a href="status_complete.html">View Details</a></p>
				                           </div>
				                           <div class="ml-auto">
				                              <p class="bg-success text-white py-1 px-2 rounded small mb-1">Delivered</p>
				                              <p class="small font-weight-bold text-center"><i class="feather-clock"></i> 06/04/2020</p>
				                           </div>
				                        </div>
				                        <div class="d-flex pt-3">
				                           <div class="small">
				                              <p class="text- font-weight-bold mb-0">Kesar Sweet x 1</p>
				                              <p class="text- font-weight-bold mb-0">Gulab Jamun x 4</p>
				                           </div>
				                           <div class="text-muted m-0 ml-auto mr-3 small">Total Payment<br>
				                              <span class="text-dark font-weight-bold">$12.74</span>
				                           </div>
				                           <div class="text-right">
				                              <a href="checkout.html" class="btn btn-primary px-3">Reorder</a>
				                              <a href="contact-us.html" class="btn btn-outline-primary px-3">Help</a>
				                           </div>
				                        </div>
				                     </div>
				                  </div>
				               </div>
				            </div>
				            <div class="tab-pane fade" id="progress" role="tabpanel" aria-labelledby="progress-tab">
				               <div class="order-body">
				                  <div class="pb-3">
				                     <div class="p-3 rounded shadow-sm bg-white">
				                        <div class="d-flex border-bottom pb-3">
				                           <div class="text-muted mr-3">
				                              <img alt="#" src="img/popular1.png" class="img-fluid order_img rounded">
				                           </div>
				                           <div>
				                              <p class="mb-0 font-weight-bold"><a href="restaurant.html" class="text-dark">Conrad Chicago Restaurant</a></p>
				                              <p class="mb-0">Punjab, India</p>
				                              <p>ORDER #321DERS</p>
				                              <p class="mb-0 small"><a href="status_onprocess.html">View Details</a></p>
				                           </div>
				                           <div class="ml-auto">
				                              <p class="bg-warning text-white py-1 px-2 rounded small mb-1">On Process</p>
				                              <p class="small font-weight-bold text-center"><i class="feather-clock"></i> 06/04/2020</p>
				                           </div>
				                        </div>
				                        <div class="d-flex pt-3">
				                           <div class="small">
				                              <p class="text- font-weight-bold mb-0">Kesar Sweet x 1</p>
				                              <p class="text- font-weight-bold mb-0">Gulab Jamun x 4</p>
				                           </div>
				                           <div class="text-muted m-0 ml-auto mr-3 small">Total Payment<br>
				                              <span class="text-dark font-weight-bold">$12.74</span>
				                           </div>
				                           <div class="text-right">
				                              <a href="status_onprocess.html" class="btn btn-primary px-3">Track</a>
				                              <a href="contact-us.html" class="btn btn-outline-primary px-3">Help</a>
				                           </div>
				                        </div>
				                     </div>
				                  </div>
				                  <div class="pb-3">
				                     <div class="p-3 rounded shadow-sm bg-white">
				                        <div class="d-flex border-bottom pb-3">
				                           <div class="text-muted mr-3">
				                              <img alt="#" src="img/popular2.png" class="img-fluid order_img rounded">
				                           </div>
				                           <div>
				                              <p class="mb-0 font-weight-bold"><a href="restaurant.html" class="text-dark">Conrad Chicago Restaurant</a></p>
				                              <p class="mb-0">Punjab, India</p>
				                              <p>ORDER #321DERS</p>
				                              <p class="mb-0 small"><a href="status_onprocess.html">View Details</a></p>
				                           </div>
				                           <div class="ml-auto">
				                              <p class="bg-warning text-white py-1 px-2 rounded small mb-1">On Process</p>
				                              <p class="small font-weight-bold text-center"><i class="feather-clock"></i> 06/04/2020</p>
				                           </div>
				                        </div>
				                        <div class="d-flex pt-3">
				                           <div class="small">
				                              <p class="text- font-weight-bold mb-0">Kesar Sweet x 1</p>
				                              <p class="text- font-weight-bold mb-0">Gulab Jamun x 4</p>
				                           </div>
				                           <div class="text-muted m-0 ml-auto mr-3 small">Total Payment<br>
				                              <span class="text-dark font-weight-bold">$12.74</span>
				                           </div>
				                           <div class="text-right">
				                              <a href="status_onprocess.html" class="btn btn-primary px-3">Track</a>
				                              <a href="contact-us.html" class="btn btn-outline-primary px-3">Help</a>
				                           </div>
				                        </div>
				                     </div>
				                  </div>
				                  <div class="pb-3">
				                     <div class="p-3 rounded shadow-sm bg-white">
				                        <div class="d-flex border-bottom pb-3">
				                           <div class="text-muted mr-3">
				                              <img alt="#" src="img/popular3.png" class="img-fluid order_img rounded">
				                           </div>
				                           <div>
				                              <p class="mb-0 font-weight-bold"><a href="restaurant.html" class="text-dark">Conrad Chicago Restaurant</a></p>
				                              <p class="mb-0">Punjab, India</p>
				                              <p>ORDER #321DERS</p>
				                              <p class="mb-0 small"><a href="status_onprocess.html">View Details</a></p>
				                           </div>
				                           <div class="ml-auto">
				                              <p class="bg-warning text-white py-1 px-2 rounded small mb-1">On Process</p>
				                              <p class="small font-weight-bold text-center"><i class="feather-clock"></i> 06/04/2020</p>
				                           </div>
				                        </div>
				                        <div class="d-flex pt-3">
				                           <div class="small">
				                              <p class="text- font-weight-bold mb-0">Kesar Sweet x 1</p>
				                              <p class="text- font-weight-bold mb-0">Gulab Jamun x 4</p>
				                           </div>
				                           <div class="text-muted m-0 ml-auto mr-3 small">Total Payment<br>
				                              <span class="text-dark font-weight-bold">$12.74</span>
				                           </div>
				                           <div class="text-right">
				                              <a href="status_onprocess.html" class="btn btn-primary px-3">Track</a>
				                              <a href="contact-us.html" class="btn btn-outline-primary px-3">Help</a>
				                           </div>
				                        </div>
				                     </div>
				                  </div>
				               </div>
				            </div>
				            <div class="tab-pane fade" id="canceled" role="tabpanel" aria-labelledby="canceled-tab">
				               <div class="order-body">
				                  <div class="pb-3">
				                     <div class="p-3 rounded shadow-sm bg-white">
				                        <div class="d-flex border-bottom pb-3">
				                           <div class="text-muted mr-3">
				                              <img alt="#" src="img/popular6.png" class="img-fluid order_img rounded">
				                           </div>
				                           <div>
				                              <p class="mb-0 font-weight-bold"><a href="restaurant.html" class="text-dark">Conrad Chicago Restaurant</a></p>
				                              <p class="mb-0">Punjab, India</p>
				                              <p>ORDER #321DERS</p>
				                              <p class="mb-0 small"><a href="status_canceled.html">View Details</a></p>
				                           </div>
				                           <div class="ml-auto">
				                              <p class="bg-danger text-white py-1 px-2 rounded small mb-1">Payment failed</p>
				                              <p class="small font-weight-bold text-center"><i class="feather-clock"></i> 06/04/2020</p>
				                           </div>
				                        </div>
				                        <div class="d-flex pt-3">
				                           <div class="small">
				                              <p class="text- font-weight-bold mb-0">Kesar Sweet x 1</p>
				                              <p class="text- font-weight-bold mb-0">Gulab Jamun x 4</p>
				                           </div>
				                           <div class="text-muted m-0 ml-auto mr-3 small">Total Payment<br>
				                              <span class="text-dark font-weight-bold">$12.74</span>
				                           </div>
				                           <div class="text-right">
				                              <a href="contact-us.html" class="btn btn-outline-primary px-3">Help</a>
				                           </div>
				                        </div>
				                     </div>
				                  </div>
				                  <div class="pb-3">
				                     <div class="p-3 rounded shadow-sm bg-white">
				                        <div class="d-flex border-bottom pb-3">
				                           <div class="text-muted mr-3">
				                              <img alt="#" src="img/popular6.png" class="img-fluid order_img rounded">
				                           </div>
				                           <div>
				                              <p class="mb-0 font-weight-bold"><a href="restaurant.html" class="text-dark">Conrad Chicago Restaurant</a></p>
				                              <p class="mb-0">Punjab, India</p>
				                              <p>ORDER #321DERS</p>
				                              <p class="mb-0 small"><a href="status_canceled.html">View Details</a></p>
				                           </div>
				                           <div class="ml-auto">
				                              <p class="bg-danger text-white py-1 px-2 rounded small mb-1">Canceled</p>
				                              <p class="small font-weight-bold text-center"><i class="feather-clock"></i> 06/04/2020</p>
				                           </div>
				                        </div>
				                        <div class="d-flex pt-3">
				                           <div class="small">
				                              <p class="text- font-weight-bold mb-0">Kesar Sweet x 1</p>
				                              <p class="text- font-weight-bold mb-0">Gulab Jamun x 4</p>
				                           </div>
				                           <div class="text-muted m-0 ml-auto mr-3 small">Total Payment<br>
				                              <span class="text-dark font-weight-bold">$12.74</span>
				                           </div>
				                           <div class="text-right">
				                              <a href="contact-us.html" class="btn btn-outline-primary px-3">Help</a>
				                           </div>
				                        </div>
				                     </div>
				                  </div>
				               </div>
				            </div>
				         </div>
				      </div>
				   </div>
				</section>
				
				<div class="quotation-dtl text-white">
					<p><i class="las la-mobile"></i>We are available at Mon-Fri call us<a href="tel:" title="contact no."> + 212-4000-300</a> during regular business hours</p>
				</div>
			</div>
		</div>
	</div>
	
	

	
	
	<!-- quotation end-->
	<!-- footer start-->
	@include('parcel.footer')
	<!-- footer end-->

	<!-- Scroll Top Area -->
	<a href="#top" class="go-top" style="display: block;"><i class="las la-angle-up"></i></a>

	<!-- Jquery Library -->
	<script src="{{ url('parcelassets/js/jquery-2.min.js')}}"></script>
	<!-- Bootstrap Js -->
	<script src="{{ url('parcelassets/js/bootstrap.bundle.js')}}"></script>
	<!-- Owl Carousel js -->
	<script src="{{ url('parcelassets/js/owl.carousel.min.js')}}"></script>
	<!-- Smooth Scroll Js -->
	<script src="{{ url('parcelassets/js/smooth-scroll.js')}}"></script>
	<!-- Navigation JS -->
	<script src="{{ url('parcelassets/js/menumaker.js')}}"></script>
	<!-- Way Points JS -->
	<script src="{{ url('parcelassets/js/waypoints.min.js')}}"></script>
	<!-- Counter Up JS -->
	<script src="{{ url('parcelassets/js/jquery.counterup.js')}}"></script>
	<!-- Sticky JS -->
	<script src="{{ url('parcelassets/js/jquery.sticky.js')}}"></script>
	<!-- Slicknav JS -->
	<script src="{{ url('parcelassets/js/jquery.slicknav.min.js')}}"></script>
	<!-- Mail Chimp JS -->
	<script src="{{ url('parcelassets/vendor/mailchimp/jquery.ajaxchimp.js')}}"></script>
	<!-- Main JS -->
	<script src="{{ url('parcelassets/js/theme.js')}}"></script>
	<!-- end JS -->

</body>
<!-- body end -->



</html>
