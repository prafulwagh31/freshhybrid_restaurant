<!DOCTYPE html>

<html lang="en">
<!-- head -->



<head>
	<meta charset="utf-8" />
	<title>Excelsure | Courier &amp; Delivery Service HTML Template</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Excelsure - Courier Service HTML Template" />
	<meta name="keywords" content="Excelsure">
	<meta name="author" content="Capricorn_Theme" />
	<meta name="MobileOptimized" content="320" />

	<!-- google fonts -->
	<link href="../../../fonts.googleapis.com/css6079.css?family=Poppins:300,400,500,600,700" rel="stylesheet">
	<link href="../../../fonts.googleapis.com/css1fd7.css?family=Roboto:400,500,700" rel="stylesheet">

	<!-- Favicon -->
	<link rel="icon" type="image/icon" href="{{ url('parcelassets/images/icons/favicon.png')}}">
	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="{{ url('parcelassets/css/bootstrap.min.css')}}" type="text/css" />
	<!-- Navigation CSS -->
	<link rel="stylesheet" type="text/css" href="{{ url('parcelassets/css/menumaker.css')}}" />
	<!-- Animated CSS -->
	<link rel="stylesheet" type="text/css" href="{{ url('parcelassets/css/animate.css')}}" />
	<!-- Owl Carousel css -->
	<link rel="stylesheet" type="text/css" href="{{ url('parcelassets/css/owl.carousel.min.css')}}" />
	<!-- Line Awesome CSS -->
	<link rel="stylesheet" type="text/css" href="{{ url('parcelassets/css/line-awesome.min.css')}}" />
	<!-- Flaticon CSS -->
	<link rel="stylesheet" type="text/css" href="{{ url('parcelassets/css/flaticon.css')}}" />
	<!-- Slicknav CSS -->
	<link rel="stylesheet" type="text/css" href="{{ url('parcelassets/css/slicknav.min.css')}}" />
	<!-- Main Style CSS -->
	<link href="{{ url('parcelassets/css/style.css')}}" rel="stylesheet" type="text/css" />
	<!-- end theme styles -->
	<!-- Responsive CSS -->
	<link href="{{ url('parcelassets/css/responsive.css')}}" rel="stylesheet">

</head>
<style type="text/css">
	#nav-bar
	{
		background-color: #147b88 !important;
	}
	.quotation-block {
    position: relative !important;
    box-shadow: 0px 0px 30px 0px rgb(18 27 81 / 10%);
	}
	@media (max-width: 575px){
	#quotation {
	    
	    height: 1800px !important;
	  
	}

	}
	@media (max-width: 768px){
	#quotation {
	    
	    height: 1500px !important;
	  
	}
	@media (max-width: 425px){
	#quotation {
	    
	    height: 1900px !important;
	  
	}
	}
	@media (max-width: 320px){
	#quotation {
	    
	    height: 2000px !important;
	  
	}
	}
</style>
<!-- end head -->
<!-- body start-->

<body>
	@include('parcel.header')
	<!-- home slider start-->
	
	<!-- home slider end-->

	<!-- services start -->
	<br><br>
	<div id="quotation" class="quotation-main-block" style="background-image: url('images/bg/consult-bg.jpg');height:1450px;">
		<div class="overlay-bg"></div>
		<div class="container">
			<div class="section text-center">
				<h1 class="section-heading">Parcel Details</h1>
			</div>
			<div class="quotation-block">

				<form class="quotation-form" method="POST" action="{{ route('parcel.addorder',Request::route('id')) }}">
					<div class="row" style="padding-top: 10px">
						<div class="col-md-6 col-sm-6">
							<div class="row" style="padding-top: 10px">
								<div class="col-md-12 col-sm-12"><h5><b>Sender Address</b></h5><hr></div>
								<div class="form-list">
									<div class="col-md-6 col-sm-6"><label for="name">Name</label></div>
		                  			<div class="col-md-6 col-sm-6">{{$sourceaddress->source_name}}</div>
	                  			</div>
	                  			<div class="form-list">
	                  				<div class="col-md-6 col-sm-6"><label for="name">Phone</label></div>
	                  				<div class="col-md-6 col-sm-6">{{$sourceaddress->source_phone}}</div>
	                  			</div>
	                  			<div class="form-list">
	                  				<div class="col-md-6 col-sm-6"><label for="name">House Number</label></div>
	                   				<div class="col-md-6 col-sm-6">{{$sourceaddress->source_houseno}}</div>
	                   			</div>
	                   			<div class="form-list">
	                   				<div class="col-md-6 col-sm-6"><label for="name">Landmark</label></div>
                   					<div class="col-md-6 col-sm-6">{{$sourceaddress->source_landmark}}</div>
                   				</div>
                   				<div class="form-list">
                   					<div class="col-md-6 col-sm-6"><label for="name">Address</label></div>
                   					<div class="col-md-6 col-sm-6">{{$sourceaddress->source_add}}</div>
                   				</div>
                   				<div class="form-list">
                   					<div class="col-md-6 col-sm-6"><label for="name">City</label></div>
                   					<div class="col-md-6 col-sm-6">{{$sourceaddress->source_city}}</div>
                   				</div>
                   				<div class="form-list">
                   					<div class="col-md-6 col-sm-6"><label for="name">State</label></div>
                   					<div class="col-md-6 col-sm-6">{{$sourceaddress->source_state}}</div>
                   				</div>
                   			</div>
						</div>
						<div class="col-md-6 col-sm-6"> 
							<div class="row" style="padding-top: 10px">
								<div class="col-md-12 col-sm-12"><h5><b>Receiver Address</b></h5><hr></div>
								<div class="form-list">
									<div class="col-md-6 col-sm-6"><label for="name">Name</label></div>
		                  			<div class="col-md-6 col-sm-6">{{$recieveraddress->destination_name}}</div>
	                  			</div>
	                  			<div class="form-list">
	                  				<div class="col-md-6 col-sm-6"><label for="name">Phone</label></div>
	                   				<div class="col-md-6 col-sm-6">{{$recieveraddress->destination_phone}}</div>
	                   			</div>
	                   			<div class="form-list">
	                   				<div class="col-md-6 col-sm-6"><label for="name">House Number</label></div>
	                   				<div class="col-md-6 col-sm-6">{{$recieveraddress->destination_houseno}}</div>
	                   			</div>
	                   			<div class="form-list">
	                   				<div class="col-md-6 col-sm-6"><label for="name">Landmark</label></div>
                  					<div class="col-md-6 col-sm-6">{{$recieveraddress->destination_landmark}}</div>
                  				</div>
                  				<div class="form-list">
                  					<div class="col-md-6 col-sm-6"><label for="name">Address</label></div>
                  					<div class="col-md-6 col-sm-6">{{$recieveraddress->destination_add}}</div>
                  				</div>
                  				<div class="form-list">
                  				    <div class="col-md-6 col-sm-6"><label for="name">City</label></div>
                  				    <div class="col-md-6 col-sm-6">{{$recieveraddress->destination_city}}</div>
                  				</div>
                  				<div class="form-list">
                  					<div class="col-md-6 col-sm-6"><label for="name">State</label></div>
                   					<div class="col-md-6 col-sm-6">{{$recieveraddress->destination_state}}</div>
                   				</div>
                   			</div>
                  		</div>
					</div>
					<div class="row" style="padding-top: 10px">
                  		<div class="col-md-6 col-sm-6">
                  			<div class="row" style="padding-top: 10px">
                  				<div class="col-md-12 col-sm-12"><h5><b>Parcel Description</b></h5><hr></div>
                  				<div class="form-list">
                  					<div class="col-md-6 col-sm-6"><label for="name">Parcel Weight</label></div>
                  					<div class="col-md-6 col-sm-6">{{$parceldetails->weight}} KG</div>
                  				</div>
                  				<div class="form-list">
                  					<div class="col-md-6 col-sm-6"><label for="name">Parcel Dimension</label></div>
			                    	<div class="col-md-6 col-sm-6">{{$parceldetails->length}} * {{$parceldetails->width}} * {{$parceldetails->height}}</div>
			                    </div>
			                    <div class="form-list">
			                      	<div class="col-md-6 col-sm-6"><label for="name">Parcel Description</label></div>
			                      	<div class="col-md-6 col-sm-6">{{$parceldetails->description}} </div>
			                    </div>
			                    <div class="form-list">
			                     	<div class="col-md-6 col-sm-6"><label for="name">Pickup Date </label></div>
			                    	<div class="col-md-6 col-sm-6">{{$parceldetails->pickup_date}} </div>
			                    </div>
			                    <div class="form-list">
			                    	<div class="col-md-6 col-sm-6"><label for="name">Pickup Time</label></div>
			                    	<div class="col-md-6 col-sm-6">{{$parceldetails->pickup_time}} </div>
			                    </div>
                  			</div>
                  		</div>
                  		<div class="col-md-6 col-sm-6">
                  			<div class="row" style="padding-top: 10px">
                  				<div class="col-md-12 col-sm-12"><h5><b>Payment Info</b></h5><hr></div>
                  				<div class="form-list">
                  					<div class="col-md-6 col-sm-6"><label for="name">Parcel Charges</label></div>
                  					<div class="col-md-6 col-sm-6">Rs.{{$parceldetails->charges}} </div>
                  				</div>
                  			</div>
                  		</div>
                  	</div>
					<br><br>
               		<h5><b>Select Payment Method</b></h5>
                	<hr>{{ csrf_field() }}
               		<div class="form-list" style="justify-content: end;align-items: end;">
						<div class="col-lg-1" style="width:25%;padding: 0px;">
							<input type="radio" name="paymentmethod" value="cash" >
						</div>
						<div class="col-lg-8" style="padding: 0px;">
							Cash
						</div>
					</div>
					<input type="hidden" name="senderid" value="{{ Request::route('senderid') }}">
					<input type="hidden" name="receiverid" value="{{ Request::route('receiverid') }}">
					<input type="hidden" name="vendor_id" value="{{ Request::route('id') }}">
					<input type="hidden" name="praceldetailid" value="{{ Request::route('orderid') }}">
					
					<div class="row">
						<div class="col-lg-4">
							
						</div>
						<div class="col-lg-4">
							<div class="request-button">
								<button type="submit" class="btn btn-primary">Submit<i class="las la-arrow-right"></i></button>
							</div>
						</div>
					</div>
				</form>
				<div class="quotation-dtl text-white">
					<p><i class="las la-mobile"></i>We are available at Mon-Fri call us<a href="tel:" title="contact no."> + 212-4000-300</a> during regular business hours</p>
				</div>
			</div>
		</div>
	</div>
	
	

	
	
	<!-- quotation end-->
	<!-- footer start-->
	@include('parcel.footer')
	<!-- footer end-->

	<!-- Scroll Top Area -->
	<a href="#top" class="go-top" style="display: block;"><i class="las la-angle-up"></i></a>

	<!-- Jquery Library -->
	<script src="{{ url('parcelassets/js/jquery-2.min.js')}}"></script>
	<!-- Bootstrap Js -->
	<script src="{{ url('parcelassets/js/bootstrap.bundle.js')}}"></script>
	<!-- Owl Carousel js -->
	<script src="{{ url('parcelassets/js/owl.carousel.min.js')}}"></script>
	<!-- Smooth Scroll Js -->
	<script src="{{ url('parcelassets/js/smooth-scroll.js')}}"></script>
	<!-- Navigation JS -->
	<script src="{{ url('parcelassets/js/menumaker.js')}}"></script>
	<!-- Way Points JS -->
	<script src="{{ url('parcelassets/js/waypoints.min.js')}}"></script>
	<!-- Counter Up JS -->
	<script src="{{ url('parcelassets/js/jquery.counterup.js')}}"></script>
	<!-- Sticky JS -->
	<script src="{{ url('parcelassets/js/jquery.sticky.js')}}"></script>
	<!-- Slicknav JS -->
	<script src="{{ url('parcelassets/js/jquery.slicknav.min.js')}}"></script>
	<!-- Mail Chimp JS -->
	<script src="{{ url('parcelassets/vendor/mailchimp/jquery.ajaxchimp.js')}}"></script>
	<!-- Main JS -->
	<script src="{{ url('parcelassets/js/theme.js')}}"></script>
	<!-- end JS -->

</body>
<!-- body end -->



</html>
