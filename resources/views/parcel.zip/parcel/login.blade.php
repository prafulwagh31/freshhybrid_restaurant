<!DOCTYPE html>

<html lang="en">
<!-- head -->



<head>
	<meta charset="utf-8" />
	<title>Excelsure | Courier &amp; Delivery Service HTML Template</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Excelsure - Courier Service HTML Template" />
	<meta name="keywords" content="Excelsure">
	<meta name="author" content="Capricorn_Theme" />
	<meta name="MobileOptimized" content="320" />

	<!-- google fonts -->
	<link href="../../../fonts.googleapis.com/css6079.css?family=Poppins:300,400,500,600,700" rel="stylesheet">
	<link href="../../../fonts.googleapis.com/css1fd7.css?family=Roboto:400,500,700" rel="stylesheet">

	<!-- Favicon -->
	<link rel="icon" type="image/icon" href="{{ url('parcelassets/images/icons/favicon.png')}}">
	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="{{ url('parcelassets/css/bootstrap.min.css')}}" type="text/css" />
	<!-- Navigation CSS -->
	<link rel="stylesheet" type="text/css" href="{{ url('parcelassets/css/menumaker.css')}}" />
	<!-- Animated CSS -->
	<link rel="stylesheet" type="text/css" href="{{ url('parcelassets/css/animate.css')}}" />
	<!-- Owl Carousel css -->
	<link rel="stylesheet" type="text/css" href="{{ url('parcelassets/css/owl.carousel.min.css')}}" />
	<!-- Line Awesome CSS -->
	<link rel="stylesheet" type="text/css" href="{{ url('parcelassets/css/line-awesome.min.css')}}" />
	<!-- Flaticon CSS -->
	<link rel="stylesheet" type="text/css" href="{{ url('parcelassets/css/flaticon.css')}}" />
	<!-- Slicknav CSS -->
	<link rel="stylesheet" type="text/css" href="{{ url('parcelassets/css/slicknav.min.css')}}" />
	<!-- Main Style CSS -->
	<link href="{{ url('parcelassets/css/style.css')}}" rel="stylesheet" type="text/css" />
	<!-- end theme styles -->
	<!-- Responsive CSS -->
	<link href="{{ url('parcelassets/css/responsive.css')}}" rel="stylesheet">

</head>
<style type="text/css">
	.form-list {
    width: 100% !important;
    vertical-align: middle;
    margin-bottom: 20px;
     display: block !important; 
     justify-content: center; 
    align-items: center;
	}
	.btn-1{
    padding: 15px 25px;
    position: relative;
    text-align: left;
    background: #0C4D52;
    color: #fff;
    display: inline-block;
    margin-top: 10px;
    margin-right: -4px;
}
.section-heading:after {
    content: "";
    
    height: 3px;
    background-color: #F8A555;
    position: absolute;
    left: 0px;
    right: 453px !important;
    bottom: 0;
    margin: 0 auto;
}
</style>
<!-- end head -->
<!-- body start-->

<body>
	
	<!-- home slider start-->
	
	<!-- home slider end-->

	<!-- services start -->
	
	<div id="calculate" class="quotation-main-block theme-2">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-md-12">
					<div class="quote-img">
						<img src="{{ url('parcelassets/images/quote.png')}}" alt="">
					</div>
				</div>

				<div class="col-lg-6 col-md-12">
					<div class="quotation-form-area" >
						<h1 class="section-heading"> Login</h1>
						
						<div class="quote-form">
							<form action="{{ route('parcel.login')}}" method="POST" class="row">
								{{ csrf_field()}}
								<div class="form-list">
									
									<div class="col-lg-9">
										<label>Email</label>
										<input type="text" placeholder="Enter Email" name="email">
									</div>
								</div>
								<div class="form-list">
									
									<div class="col-lg-9">
											<label>Password</label>
										<input type="password" placeholder="Enter Password" name="password">
									</div>
								</div>
								<!-- <div class="row">
									<div class="col-lg-12 "> -->
										<div class="cost-center" style="padding-left:20px;">
											<button class="btn-1"> <i class="las la-arrow-circle-right"> </i> &nbsp;&nbsp;Login  </button>
										</div>
									<!-- </div>
								</div> -->
							</form>
							<br>
							<p>Don't have account? <a href="{{ route('parcel.signup')}}"> Sign up</a></p>
							 
							
						</div>
					</div>
				</div>

			</div>
		</div>
	</div>

	
	<!-- quotation end-->
	<!-- footer start-->
	
	<!-- footer end-->

	<!-- Scroll Top Area -->
	<a href="#top" class="go-top" style="display: block;"><i class="las la-angle-up"></i></a>

	<!-- Jquery Library -->
	<script src="{{ url('parcelassets/js/jquery-2.min.js')}}"></script>
	<!-- Bootstrap Js -->
	<script src="{{ url('parcelassets/js/bootstrap.bundle.js')}}"></script>
	<!-- Owl Carousel js -->
	<script src="{{ url('parcelassets/js/owl.carousel.min.js')}}"></script>
	<!-- Smooth Scroll Js -->
	<script src="{{ url('parcelassets/js/smooth-scroll.js')}}"></script>
	<!-- Navigation JS -->
	<script src="{{ url('parcelassets/js/menumaker.js')}}"></script>
	<!-- Way Points JS -->
	<script src="{{ url('parcelassets/js/waypoints.min.js')}}"></script>
	<!-- Counter Up JS -->
	<script src="{{ url('parcelassets/js/jquery.counterup.js')}}"></script>
	<!-- Sticky JS -->
	<script src="{{ url('parcelassets/js/jquery.sticky.js')}}"></script>
	<!-- Slicknav JS -->
	<script src="{{ url('parcelassets/js/jquery.slicknav.min.js')}}"></script>
	<!-- Mail Chimp JS -->
	<script src="{{ url('parcelassets/vendor/mailchimp/jquery.ajaxchimp.js')}}"></script>
	<!-- Main JS -->
	<script src="{{ url('parcelassets/js/theme.js')}}"></script>
	<!-- end JS -->

</body>
<!-- body end -->



</html>
