<style>
	.top-nav .dropdown {
    border-left: 0px solid #EDEDED !important;
    padding-left: 10px;
}
</style>
<!-- preloader -->
	<div class="preloader">
		<div class="spinner">
			<div class="double-bounce1"></div>
			<div class="double-bounce2"></div>
		</div>
	</div>

	<!-- end preloader -->
	<!-- top bar start-->
	<div id="top-bar" class="top-bar-main-block">
		<div class="container">
			<div class="row">
				<div class="col-md-3">
					<div class="top-nav">
						<ul>
							@if(session('user_id') != '')
								<li class="dropdown language-select">
									<a href="#" data-toggle="dropdown" title=""><i class="las la-user"></i>{{session('name')}}<i class="las la-caret-square-down"></i></a>
									<ul class="dropdown-menu">
										<li><a href="{{ route('parcel.orderlist')}}" title="Orders"><i class="las la-list" style="margin:0px !important"></i>Order List</a></li>
										<li><a href="{{ route('parcel.logout')}}" title="Logout"><i class="las la-lock" style="margin:0px !important"></i>Logout</a></li>
										
									</ul>
								</li>
							@else 
								<li class="login"><a href="{{ route('parcel.login')}}" title="Login"><i class="las la-share-square"></i> Login </a></li>
								<li><a href="{{ route('parcel.signup')}}" title="Create an account"><i class="las la-user"></i> Create an account</a></li>
							@endif
							
							
						</ul>
					</div>
				</div>
					
		               <div class="col-md-5">  
		               		@if(session()->has('error_message'))
			                <center><div class="alert alert-danger" style="padding: 0px !important;margin-bottom: 0px !important;">{{ session('error_message') }}</div></center>
			                @endif
			                @if(session()->has('success_message'))
			                <center><div class="alert alert-success">{{ session('success_message') }}</div></center>
			                @endif
		            	 </div>
    			
				
				<div class="col-md-4 text-right">
					<div class="top-bar-social">
						<ul>
							<li class="call"><i class="las la-phone-volume"></i>Call us at: <a href="tel:" title="">1900-900-8899</a></li>
							<li><a href="https://facebook.com/" target="_blank" title="facebook"><i class="lab la-facebook-f"></i></a></li>
							<li><a href="https://twitter.com/" target="_blank" title="twitter"><i class="lab la-twitter"></i></a></li>
							<li><a href="https://plus.google.com/" target="_blank" title="google-plus"><i class="lab la-linkedin-in"></i></a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- top bar end-->
	<!-- top-nav bar start-->
	@php
	$vendorCategory = DB::table('vendor_category')->where('ui_type',4)->first();

	@endphp
	<div id="nav-bar" class="nav-bar-main-block absolute">
		<div class="sticky-area">
			<div class="container">
				<div class="row">
					<div class="col-lg-2">
						<div class="logo">
							<a href="{{ route('parcel.parcelhome',4)}}" title="logo"><img src="{{ url($vendorCategory->category_image)}}" style="width:150px;height:45px" alt="logo"></a>
						</div>
						<!-- Responsive Menu Area -->
						<div class="responsive-menu-wrap"></div>
					</div>
					<div class="col-lg-3">
						<div class="navigation-btn">
							<a href="#" class="btn btn-primary" title="Location">Set Location</a>
						</div>
					</div>
					<div class="col-lg-7">
						<div class="navigation text-white theme-2">
							<div id="cssmenu">
								<ul>
									<li><a href="#" title="contact">Home</a>
									</li>
									<li><a href="#" title="contact">About</a>
									</li>
									<li><a href="#" title="contact">Faq</a>
									</li>
									<li><a href="#" title="contact">Contact</a>
									</li>
									<!-- <li class="active"><a href="#" title="Home">Home +</a>
										<ul>
											<li><a href="index-2.html" title="home">Home-1</a></li>
											<li><a href="home-2.html" title="home-2">Home-2</a></li>
											<li class="active"><a href="home-3.html" title="home-3">Home-3</a></li>
										</ul>
									</li>
									<li><a href="#" title="Pages">Pages +</a>
										<ul>
											<li><a href="about.html" title="About">About</a></li>
											<li><a href="team.html" title="Team">Team</a></li>
											<li><a href="quotation.html" title="Quotation">Quotation</a></li>
											<li><a href="faq.html" title="Faq">Faq</a></li>
										</ul>
									</li>
									<li><a href="#" title="services">Services +</a>
										<ul>
											<li><a href="services.html" title="Services">Services</a></li>
											<li><a href="service-details.html" title="Service Details">Service Details</a></li>
										</ul>
									</li>
									<li><a href="pricing.html" title="pricing">Pricing</a>
									</li>
									<li><a href="#" title="blog">Blog +</a>
										<ul>
											<li><a href="blog.html" title="Blog">Blog</a></li>
											<li><a href="blog-details.html" title="Blog Detail">Blog Details</a></li>
										</ul>
									</li>
									<li><a href="contact.html" title="contact">Contact</a>
									</li> -->
								</ul>
							</div>
						</div>
					</div>
					<!-- <div class="col-lg-2">
						<div class="navigation-btn">
							<a href="#" class="btn btn-primary" title="get quotes">Get Quotes</a>
						</div>
					</div> -->
				</div>
			</div>
		</div>
	</div>
	<!-- top-nav bar end-->