<!DOCTYPE html>

<html lang="en">
<!-- head -->



<head>
	<meta charset="utf-8" />
	<title>Excelsure | Courier &amp; Delivery Service HTML Template</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Excelsure - Courier Service HTML Template" />
	<meta name="keywords" content="Excelsure">
	<meta name="author" content="Capricorn_Theme" />
	<meta name="MobileOptimized" content="320" />

	<!-- google fonts -->
	<link href="../../../fonts.googleapis.com/css6079.css?family=Poppins:300,400,500,600,700" rel="stylesheet">
	<link href="../../../fonts.googleapis.com/css1fd7.css?family=Roboto:400,500,700" rel="stylesheet">

	<!-- Favicon -->
	<link rel="icon" type="image/icon" href="{{ url('parcelassets/images/icons/favicon.png')}}">
	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="{{ url('parcelassets/css/bootstrap.min.css')}}" type="text/css" />
	<!-- Navigation CSS -->
	<link rel="stylesheet" type="text/css" href="{{ url('parcelassets/css/menumaker.css')}}" />
	<!-- Animated CSS -->
	<link rel="stylesheet" type="text/css" href="{{ url('parcelassets/css/animate.css')}}" />
	<!-- Owl Carousel css -->
	<link rel="stylesheet" type="text/css" href="{{ url('parcelassets/css/owl.carousel.min.css')}}" />
	<!-- Line Awesome CSS -->
	<link rel="stylesheet" type="text/css" href="{{ url('parcelassets/css/line-awesome.min.css')}}" />
	<!-- Flaticon CSS -->
	<link rel="stylesheet" type="text/css" href="{{ url('parcelassets/css/flaticon.css')}}" />
	<!-- Slicknav CSS -->
	<link rel="stylesheet" type="text/css" href="{{ url('parcelassets/css/slicknav.min.css')}}" />
	<!-- Main Style CSS -->
	<link href="{{ url('parcelassets/css/style.css')}}" rel="stylesheet" type="text/css" />
	<!-- end theme styles -->
	<!-- Responsive CSS -->
	<link href="{{ url('parcelassets/css/responsive.css')}}" rel="stylesheet">

</head>
<style type="text/css">
	#nav-bar
	{
		background-color: #147b88 !important;
	}
	.quotation-block {
    position: relative !important;
    box-shadow: 0px 0px 30px 0px rgb(18 27 81 / 10%);
	}
	@media (max-width: 575px){
	#quotation {
	    
	    height: 1200px !important;
	  
	}

	}
	@media (max-width: 768px){
	#quotation {
	    
	    height: 1250px !important;
	  
	}
	}
</style>
<!-- end head -->
<!-- body start-->

<body>
	@include('parcel.header')
	<!-- home slider start-->
	
	<!-- home slider end-->

	<!-- services start -->
	<br><br>
	<div id="quotation" class="quotation-main-block" style="background-image: url('images/bg/consult-bg.jpg');height:1050px;">
		<div class="overlay-bg"></div>
		<div class="container">
			<div class="section text-center">
				<h1 class="section-heading">Receiver Details</h1>
			</div>
			<div class="quotation-block">
				<form class="quotation-form" method="POST" action="{{ route('parcel.receiverdetails',Request::route('id')) }}">
					{{ csrf_field() }}
					<input type="hidden" name="senderid" value="{{ Request::route('senderid') }}">
					<div class="row">
						<div class="col-lg-6 col-sm-6">
							<div class="form-group">
								<label for="name">Name</label>
								<input type="text" class="form-control" name="receivername" id="name" placeholder="Full Name" required>
							</div>
						</div>
						<div class="col-lg-6 col-sm-6">
							<div class="form-group">
								<label for="email">Email</label>
								<input type="email" class="form-control" name="senderemail" id="email" placeholder="Email" required>
							</div>
						</div>
						<div class="col-lg-6">
							<div class="form-group">
								<label for="phone">Contact No.</label>
								<input type="text" class="form-control" name="receivercontact" id="phone" placeholder="Phone No." required>
							</div>
						</div>
						<div class="col-lg-6">
							<div class="form-group">
								<label for="phone">House/Flat No.</label>
								<input type="text" class="form-control" name="receiverhouseno" id="phone" placeholder="House/Flat No." required>
							</div>
						</div>
						<div class="col-lg-6">
							<div class="form-group">
								<label for="phone">Landmark</label>
								<input type="text" class="form-control" name="receiverlandmark" id="phone" placeholder="Landmark" required>
							</div>
						</div>
						<div class="col-lg-6">
							<div class="form-group">
								<label for="phone">City</label>
								<input type="text" class="form-control"  name="receivercity" id="phone" placeholder="City" required>
							</div>
						</div>
						<div class="col-lg-6">
							<div class="form-group">
								<label for="phone">Pincode</label>
								<input type="text" class="form-control" name="receiverpincode" id="phone" placeholder="Pincode" required>
							</div>
						</div>
						<div class="col-lg-6">
							<div class="form-group">
								<label for="phone">State</label>
								<input type="text" class="form-control" name="receiverstate" id="phone" placeholder="State" required>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-lg-4">
							
						</div>
						<div class="col-lg-4">
							<div class="request-button">
								<button type="submit" class="btn btn-primary">Submit<i class="las la-arrow-right"></i></button>
							</div>
						</div>
					</div>
				</form>
				<div class="quotation-dtl text-white">
					<p><i class="las la-mobile"></i>We are available at Mon-Fri call us<a href="tel:" title="contact no."> + 212-4000-300</a> during regular business hours</p>
				</div>
			</div>
		</div>
	</div>
	
	

	
	
	<!-- quotation end-->
	<!-- footer start-->
	@include('parcel.footer')
	<!-- footer end-->

	<!-- Scroll Top Area -->
	<a href="#top" class="go-top" style="display: block;"><i class="las la-angle-up"></i></a>

	<!-- Jquery Library -->
	<script src="{{ url('parcelassets/js/jquery-2.min.js')}}"></script>
	<!-- Bootstrap Js -->
	<script src="{{ url('parcelassets/js/bootstrap.bundle.js')}}"></script>
	<!-- Owl Carousel js -->
	<script src="{{ url('parcelassets/js/owl.carousel.min.js')}}"></script>
	<!-- Smooth Scroll Js -->
	<script src="{{ url('parcelassets/js/smooth-scroll.js')}}"></script>
	<!-- Navigation JS -->
	<script src="{{ url('parcelassets/js/menumaker.js')}}"></script>
	<!-- Way Points JS -->
	<script src="{{ url('parcelassets/js/waypoints.min.js')}}"></script>
	<!-- Counter Up JS -->
	<script src="{{ url('parcelassets/js/jquery.counterup.js')}}"></script>
	<!-- Sticky JS -->
	<script src="{{ url('parcelassets/js/jquery.sticky.js')}}"></script>
	<!-- Slicknav JS -->
	<script src="{{ url('parcelassets/js/jquery.slicknav.min.js')}}"></script>
	<!-- Mail Chimp JS -->
	<script src="{{ url('parcelassets/vendor/mailchimp/jquery.ajaxchimp.js')}}"></script>
	<!-- Main JS -->
	<script src="{{ url('parcelassets/js/theme.js')}}"></script>
	<!-- end JS -->

</body>
<!-- body end -->



</html>
